<?php
session_start();
require_once 'db.php';

// Require controllers
require_once 'controllers/EventController.php';

// Require models
require_once 'models/Event.php';
require_once 'models/Ticket.php';
require_once 'models/User.php';
require_once 'models/Log.php'; // ✅ Needed for LogObserver

// ✅ Attach LogObserver globally
$logObserver = new LogObserver($conn);
Event::attach($logObserver);
Ticket::attach($logObserver);
User::attach($logObserver);

// Instantiate controller
$controller = new EventController($conn);

// Determine action from query string
$action = $_GET['action'] ?? 'home';
$id     = isset($_GET['id']) ? (int) $_GET['id'] : null;

// Helper: redirect with error
function redirectWithError($message) {
    $_SESSION['error'] = $message;
    header("Location: events.php?action=home");
    exit;
}

try {
    switch ($action) {
        /* ---------------- HOME ---------------- */
        case 'home':
            $controller->home();
            break;

        /* ---------------- EVENTS LIST ---------------- */
        case 'list':
            $controller->listEvents();
            break;
            
        /* ---------------- EVENT DETAILS ---------------- */
        case 'details':
            if ($id) {
                $controller->showDetails($id);
            } else {
                redirectWithError("Event ID is missing.");
            }
            break;

        /* ---------------- JSON ENDPOINTS ---------------- */
        case 'listJson':
            header('Content-Type: application/json');
            try {
                echo json_encode(Event::getActiveEvents($conn));
            } catch (Exception $e) {
                echo json_encode(['error' => $e->getMessage()]);
            }
            exit;

        case 'detailsJson':
            header('Content-Type: application/json');
            try {
                if ($id) {
                    echo json_encode(Event::getById($conn, $id));
                } else {
                    echo json_encode(['error' => 'Event ID is missing']);
                }
            } catch (Exception $e) {
                echo json_encode(['error' => $e->getMessage()]);
            }
            exit;

        /* ---------------- DEFAULT ---------------- */
        default:
            redirectWithError("Invalid action requested.");
            break;
    }
} catch (Exception $e) {
    redirectWithError($e->getMessage());
}