<?php

namespace Tests;

use PHPUnit\Framework\TestCase;
use mysqli;

/**
 * Base test case for database tests in Eventify
 */
class DatabaseTestCase extends TestCase
{
    protected static $conn = null;
    protected static $dbInitialized = false;

    /**
     * Set up test database before all tests
     */
    public static function setUpBeforeClass(): void
    {
        parent::setUpBeforeClass();
        
        // Create connection to test database
        mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
        
        try {
            self::$conn = new mysqli("localhost", "root", "", "eventify_test");
            
            // Create tables if they don't exist
            self::initializeDatabase();
            
            echo "✓ Test database connected\n";
        } catch (\Exception $e) {
            echo "✗ Database connection failed: " . $e->getMessage() . "\n";
            throw $e;
        }
    }

    /**
     * Initialize test database tables
     */
    protected static function initializeDatabase(): void
    {
        if (self::$dbInitialized) {
            return;
        }

        // Create users table (matching your actual structure)
        self::$conn->query("
            CREATE TABLE IF NOT EXISTS users (
                id INT AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(100) NOT NULL,
                email VARCHAR(100) NOT NULL UNIQUE,
                password VARCHAR(255) NOT NULL,
                role ENUM('user', 'admin') DEFAULT 'user',
                status ENUM('active', 'banned') DEFAULT 'active',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ");
        
        // Create logs table for Observer pattern
        self::$conn->query("
            CREATE TABLE IF NOT EXISTS logs (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT,
                action VARCHAR(100),
                description TEXT,
                ip_address VARCHAR(45),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ");

        // Create events table
        self::$conn->query("
            CREATE TABLE IF NOT EXISTS events (
                id INT AUTO_INCREMENT PRIMARY KEY,
                title VARCHAR(200) NOT NULL,
                description TEXT,
                event_date DATETIME NOT NULL,
                location VARCHAR(255),
                capacity INT DEFAULT 0,
                price DECIMAL(10,2) DEFAULT 0.00,
                created_by INT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (created_by) REFERENCES users(id)
            )
        ");

        // Create tickets table
        self::$conn->query("
            CREATE TABLE IF NOT EXISTS tickets (
                id INT AUTO_INCREMENT PRIMARY KEY,
                event_id INT NOT NULL,
                user_id INT NOT NULL,
                quantity INT DEFAULT 1,
                total_price DECIMAL(10,2),
                status ENUM('pending', 'confirmed', 'cancelled') DEFAULT 'pending',
                booked_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (event_id) REFERENCES events(id),
                FOREIGN KEY (user_id) REFERENCES users(id)
            )
        ");

        // Create logs table
        self::$conn->query("
            CREATE TABLE IF NOT EXISTS logs (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT,
                action VARCHAR(100),
                description TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id)
            )
        ");

        self::$dbInitialized = true;
    }

    /**
     * Set up fresh state before each test
     */
    protected function setUp(): void
    {
        parent::setUp();
        
        // Start transaction for test isolation
        self::$conn->begin_transaction();
    }

    /**
     * Clean up after each test
     */
    protected function tearDown(): void
    {
        // Rollback transaction to reset database
        if (self::$conn) {
            self::$conn->rollback();
        }
        
        parent::tearDown();
    }

    /**
     * Get database connection
     */
    protected function getConnection(): mysqli
    {
        return self::$conn;
    }

    /**
     * Clean up database after all tests
     */
    public static function tearDownAfterClass(): void
    {
        if (self::$conn) {
            self::$conn->close();
        }
        parent::tearDownAfterClass();
    }

    /**
     * Helper: Insert test user
     */
    protected function insertTestUser($username = 'testuser', $email = 'test@example.com', $role = 'user')
    {
        $password = password_hash('password123', PASSWORD_DEFAULT);
        $stmt = self::$conn->prepare("INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $username, $email, $password, $role);
        $stmt->execute();
        return self::$conn->insert_id;
    }

    /**
     * Helper: Insert test event
     */
    protected function insertTestEvent($title = 'Test Event', $userId = 1)
    {
        $description = 'Test event description';
        $eventDate = date('Y-m-d H:i:s', strtotime('+7 days'));
        $location = 'Test Location';
        $capacity = 100;
        $price = 50.00;
        
        $stmt = self::$conn->prepare("INSERT INTO events (title, description, event_date, location, capacity, price, created_by) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssidi", $title, $description, $eventDate, $location, $capacity, $price, $userId);
        $stmt->execute();
        return self::$conn->insert_id;
    }

    /**
     * Helper: Clear all tables
     */
    protected function clearAllTables(): void
    {
        self::$conn->query("DELETE FROM tickets");
        self::$conn->query("DELETE FROM logs");
        self::$conn->query("DELETE FROM events");
        self::$conn->query("DELETE FROM users");
    }
}