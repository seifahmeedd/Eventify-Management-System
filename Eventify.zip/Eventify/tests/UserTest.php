<?php

namespace Tests;

require_once __DIR__ . '/../models/User.php';

use User;

/**
 * Tests for User Model
 */
class UserTest extends DatabaseTestCase
{
    protected function setUp(): void
    {
        parent::setUp();
        
        // Clear tables before each test
        $conn = $this->getConnection();
        $conn->query("DELETE FROM logs");
        $conn->query("DELETE FROM users");
    }

    /* ============ REGISTRATION TESTS ============ */

    public function testCanRegisterNewUser()
    {
        $userId = User::register(
            $this->getConnection(), 
            'John Doe', 
            'john@gmail.com', 
            'Password123'
        );

        $this->assertIsInt($userId);
        $this->assertGreaterThan(0, $userId);

        // Verify user exists in database
        $user = User::getById($this->getConnection(), $userId);
        $this->assertEquals('John Doe', $user['name']);
        $this->assertEquals('john@gmail.com', $user['email']);
        $this->assertEquals('user', $user['role']);
        $this->assertEquals('active', $user['status']);
    }

    public function testCannotRegisterWithInvalidEmail()
    {
        $this->expectException(\Exception::class);
        $this->expectExceptionMessage("Invalid email format");

        User::register($this->getConnection(), 'Test', 'notanemail', 'Password123');
    }

    public function testCannotRegisterWithInvalidEmailDomain()
    {
        $this->expectException(\Exception::class);
        $this->expectExceptionMessage("Email must be Gmail, Hotmail, Outlook, or Yahoo");

        User::register($this->getConnection(), 'Test', 'test@example.com', 'Password123');
    }

    public function testCannotRegisterWithWeakPassword()
    {
        $this->expectException(\Exception::class);
        $this->expectExceptionMessage("Password must be at least 8 characters");

        User::register($this->getConnection(), 'Test', 'test@gmail.com', 'weak');
    }

    public function testCannotRegisterWithPasswordNoUppercase()
    {
        $this->expectException(\Exception::class);

        User::register($this->getConnection(), 'Test', 'test@gmail.com', 'password123');
    }

    public function testCannotRegisterWithPasswordNoNumber()
    {
        $this->expectException(\Exception::class);

        User::register($this->getConnection(), 'Test', 'test@gmail.com', 'PasswordOnly');
    }

    public function testCannotRegisterDuplicateEmail()
    {
        // First registration
        User::register($this->getConnection(), 'User One', 'duplicate@gmail.com', 'Password123');

        // Try to register again with same email
        $this->expectException(\Exception::class);
        $this->expectExceptionMessage("This email is already registered");

        User::register($this->getConnection(), 'User Two', 'duplicate@gmail.com', 'Password456');
    }

    /* ============ LOGIN TESTS ============ */

    public function testCanLoginWithValidCredentials()
    {
        // Create user
        User::register($this->getConnection(), 'Login User', 'login@gmail.com', 'Password123');

        // Try to login
        $user = User::login($this->getConnection(), 'login@gmail.com', 'Password123');

        $this->assertNotNull($user);
        $this->assertEquals('login@gmail.com', $user['email']);
        $this->assertEquals('Login User', $user['name']);
    }

    public function testCannotLoginWithWrongPassword()
    {
        User::register($this->getConnection(), 'Test', 'test@gmail.com', 'Password123');

        $user = User::login($this->getConnection(), 'test@gmail.com', 'WrongPassword123');

        $this->assertNull($user);
    }

    public function testCannotLoginWithNonExistentEmail()
    {
        $user = User::login($this->getConnection(), 'notexist@gmail.com', 'Password123');

        $this->assertNull($user);
    }

    public function testCanLoginEvenIfBanned()
    {
        // Create banned user
        $userId = User::create($this->getConnection(), 'Banned User', 'banned@gmail.com', 'Password123', 'user', 'banned');

        // Should still return user data
        $user = User::login($this->getConnection(), 'banned@gmail.com', 'Password123');

        $this->assertNotNull($user);
        $this->assertEquals('banned', $user['status']);
    }

    /* ============ CRUD TESTS ============ */

    public function testCanCreateUserAsAdmin()
    {
        $userId = User::create(
            $this->getConnection(), 
            'Admin User', 
            'admin@gmail.com', 
            'Password123', 
            'admin', 
            'active'
        );

        $this->assertIsInt($userId);

        $user = User::getById($this->getConnection(), $userId);
        $this->assertEquals('admin', $user['role']);
    }

    public function testCanUpdateUser()
    {
        $userId = User::register($this->getConnection(), 'Original', 'original@gmail.com', 'Password123');

        $result = User::update(
            $this->getConnection(), 
            $userId, 
            'Updated Name', 
            'updated@gmail.com', 
            'admin', 
            'active'
        );

        $this->assertTrue($result);

        $user = User::getById($this->getConnection(), $userId);
        $this->assertEquals('Updated Name', $user['name']);
        $this->assertEquals('updated@gmail.com', $user['email']);
        $this->assertEquals('admin', $user['role']);
    }

    public function testCannotUpdateWithInvalidRole()
    {
        $userId = User::register($this->getConnection(), 'Test', 'test@gmail.com', 'Password123');

        $this->expectException(\Exception::class);
        $this->expectExceptionMessage("Invalid role value");

        User::update($this->getConnection(), $userId, 'Test', 'test@gmail.com', 'superuser', 'active');
    }

    public function testCannotUpdateWithInvalidStatus()
    {
        $userId = User::register($this->getConnection(), 'Test', 'test@gmail.com', 'Password123');

        $this->expectException(\Exception::class);
        $this->expectExceptionMessage("Invalid status value");

        User::update($this->getConnection(), $userId, 'Test', 'test@gmail.com', 'user', 'suspended');
    }

    public function testCanDeleteUser()
    {
        $userId = User::register($this->getConnection(), 'Delete Me', 'delete@gmail.com', 'Password123');

        $result = User::delete($this->getConnection(), $userId);

        $this->assertTrue($result);

        $user = User::getById($this->getConnection(), $userId);
        $this->assertNull($user);
    }

    public function testCanGetAllUsers()
    {
        User::register($this->getConnection(), 'User 1', 'user1@gmail.com', 'Password123');
        User::register($this->getConnection(), 'User 2', 'user2@gmail.com', 'Password123');
        User::register($this->getConnection(), 'User 3', 'user3@gmail.com', 'Password123');

        $users = User::all($this->getConnection());

        $this->assertIsArray($users);
        $this->assertCount(3, $users);
    }

    public function testCanCountUsers()
    {
        User::register($this->getConnection(), 'User 1', 'user1@gmail.com', 'Password123');
        User::register($this->getConnection(), 'User 2', 'user2@gmail.com', 'Password123');

        $count = User::count($this->getConnection());

        $this->assertEquals(2, $count);
    }

    /* ============ HELPER METHOD TESTS ============ */

    public function testCanFindUserByEmail()
    {
        User::register($this->getConnection(), 'Find Me', 'findme@gmail.com', 'Password123');

        $user = User::findByEmail($this->getConnection(), 'findme@gmail.com');

        $this->assertNotNull($user);
        $this->assertEquals('Find Me', $user['name']);
    }

    public function testIsStrongPasswordValidation()
    {
        $this->assertTrue(User::isStrongPassword('Password123'));
        $this->assertTrue(User::isStrongPassword('MySecurePass1'));
        
        $this->assertFalse(User::isStrongPassword('short1'));      // Too short
        $this->assertFalse(User::isStrongPassword('nouppercase1')); // No uppercase
        $this->assertFalse(User::isStrongPassword('NoNumber'));     // No number
        $this->assertFalse(User::isStrongPassword('Pass1'));        // Too short
    }

    public function testIsValidEmailDomain()
    {
        $this->assertTrue(User::isValidEmailDomain('test@gmail.com'));
        $this->assertTrue(User::isValidEmailDomain('test@hotmail.com'));
        $this->assertTrue(User::isValidEmailDomain('test@outlook.com'));
        $this->assertTrue(User::isValidEmailDomain('test@yahoo.com'));
        
        $this->assertFalse(User::isValidEmailDomain('test@example.com'));
        $this->assertFalse(User::isValidEmailDomain('test@test.com'));
        $this->assertFalse(User::isValidEmailDomain('test@company.org'));
    }

    /* ============ EDGE CASES ============ */

    public function testGetByIdReturnsNullForNonExistent()
    {
        $user = User::getById($this->getConnection(), 99999);
        $this->assertNull($user);
    }

    public function testAllReturnsEmptyArrayWhenNoUsers()
    {
        $users = User::all($this->getConnection());
        $this->assertIsArray($users);
        $this->assertCount(0, $users);
    }

    public function testCountReturnsZeroWhenNoUsers()
    {
        $count = User::count($this->getConnection());
        $this->assertEquals(0, $count);
    }
}