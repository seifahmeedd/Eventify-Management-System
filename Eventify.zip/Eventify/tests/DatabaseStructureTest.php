<?php

namespace Tests;

require_once __DIR__ . '/DatabaseTestCase.php';

/**
 * Tests for Database Structure and Integrity
 */
class DatabaseStructureTest extends DatabaseTestCase
{
    /* ============ TABLE EXISTENCE TESTS ============ */

    public function testUsersTableExists()
    {
        $result = $this->getConnection()->query(
            "SHOW TABLES LIKE 'users'"
        );
        $this->assertEquals(1, $result->num_rows, "Users table should exist");
    }

    public function testEventsTableExists()
    {
        $result = $this->getConnection()->query(
            "SHOW TABLES LIKE 'events'"
        );
        $this->assertEquals(1, $result->num_rows, "Events table should exist");
    }

    public function testTicketsTableExists()
    {
        $result = $this->getConnection()->query(
            "SHOW TABLES LIKE 'tickets'"
        );
        $this->assertEquals(1, $result->num_rows, "Tickets table should exist");
    }

    public function testLogsTableExists()
    {
        $result = $this->getConnection()->query(
            "SHOW TABLES LIKE 'logs'"
        );
        $this->assertEquals(1, $result->num_rows, "Logs table should exist");
    }

    /* ============ USERS TABLE STRUCTURE ============ */

    public function testUsersTableHasCorrectColumns()
    {
        $result = $this->getConnection()->query("DESCRIBE users");
        $columns = [];
        while ($row = $result->fetch_assoc()) {
            $columns[] = $row['Field'];
        }

        $expectedColumns = ['id', 'name', 'email', 'password', 'role', 'status', 'created_at'];
        
        foreach ($expectedColumns as $column) {
            $this->assertContains($column, $columns, "Users table should have '$column' column");
        }
    }

    public function testUsersTableEmailIsUnique()
    {
        $result = $this->getConnection()->query("SHOW INDEXES FROM users WHERE Column_name = 'email'");
        $this->assertGreaterThan(0, $result->num_rows, "Email column should have a unique index");
    }

    public function testUsersRoleIsEnum()
    {
        $result = $this->getConnection()->query("SHOW COLUMNS FROM users LIKE 'role'");
        $row = $result->fetch_assoc();
        
        $this->assertStringContainsString('enum', strtolower($row['Type']), "Role should be ENUM type");
        $this->assertStringContainsString('admin', $row['Type'], "Role should include 'admin'");
        $this->assertStringContainsString('user', $row['Type'], "Role should include 'user'");
    }

    public function testUsersStatusIsEnum()
    {
        $result = $this->getConnection()->query("SHOW COLUMNS FROM users LIKE 'status'");
        $row = $result->fetch_assoc();
        
        $this->assertStringContainsString('enum', strtolower($row['Type']), "Status should be ENUM type");
        $this->assertStringContainsString('active', $row['Type'], "Status should include 'active'");
        $this->assertStringContainsString('banned', $row['Type'], "Status should include 'banned'");
    }

    /* ============ EVENTS TABLE STRUCTURE ============ */

    public function testEventsTableHasCorrectColumns()
    {
        $result = $this->getConnection()->query("DESCRIBE events");
        $columns = [];
        while ($row = $result->fetch_assoc()) {
            $columns[] = $row['Field'];
        }

        $expectedColumns = ['id', 'title', 'description', 'venue', 'date', 'time', 'category', 'capacity', 'price', 'status'];
        
        foreach ($expectedColumns as $column) {
            $this->assertContains($column, $columns, "Events table should have '$column' column");
        }
    }

    public function testEventsCapacityIsInteger()
    {
        $result = $this->getConnection()->query("SHOW COLUMNS FROM events LIKE 'capacity'");
        $row = $result->fetch_assoc();
        
        $this->assertStringContainsString('int', strtolower($row['Type']), "Capacity should be integer type");
    }

    public function testEventsPriceIsDecimal()
    {
        $result = $this->getConnection()->query("SHOW COLUMNS FROM events LIKE 'price'");
        $row = $result->fetch_assoc();
        
        $this->assertStringContainsString('decimal', strtolower($row['Type']), "Price should be decimal type");
    }

    /* ============ TICKETS TABLE STRUCTURE ============ */

    public function testTicketsTableHasCorrectColumns()
    {
        $result = $this->getConnection()->query("DESCRIBE tickets");
        $columns = [];
        while ($row = $result->fetch_assoc()) {
            $columns[] = $row['Field'];
        }

        $expectedColumns = ['id', 'event_id', 'user_id', 'quantity', 'total_price', 'status'];
        
        foreach ($expectedColumns as $column) {
            $this->assertContains($column, $columns, "Tickets table should have '$column' column");
        }
    }

    /* ============ LOGS TABLE STRUCTURE ============ */

    public function testLogsTableHasCorrectColumns()
    {
        $result = $this->getConnection()->query("DESCRIBE logs");
        $columns = [];
        while ($row = $result->fetch_assoc()) {
            $columns[] = $row['Field'];
        }

        $expectedColumns = ['id', 'user_id', 'action', 'description', 'created_at'];
        
        foreach ($expectedColumns as $column) {
            $this->assertContains($column, $columns, "Logs table should have '$column' column");
        }
    }

    /* ============ DATA INTEGRITY TESTS ============ */

    public function testCannotInsertDuplicateEmail()
    {
        $conn = $this->getConnection();
        
        // Insert first user
        $stmt = $conn->prepare("INSERT INTO users (name, email, password, role, status) VALUES (?, ?, ?, ?, ?)");
        $name = "User 1";
        $email = "duplicate@gmail.com";
        $password = password_hash("Password123", PASSWORD_DEFAULT);
        $role = "user";
        $status = "active";
        $stmt->bind_param("sssss", $name, $email, $password, $role, $status);
        $stmt->execute();

        // Try to insert duplicate email
        $this->expectException(\mysqli_sql_exception::class);
        $name2 = "User 2";
        $stmt->bind_param("sssss", $name2, $email, $password, $role, $status);
        $stmt->execute();
    }

    public function testCannotInsertInvalidRoleEnum()
    {
        $conn = $this->getConnection();
        
        $this->expectException(\mysqli_sql_exception::class);
        
        $stmt = $conn->prepare("INSERT INTO users (name, email, password, role, status) VALUES (?, ?, ?, ?, ?)");
        $name = "Test User";
        $email = "test@gmail.com";
        $password = password_hash("Password123", PASSWORD_DEFAULT);
        $role = "superuser"; // Invalid role
        $status = "active";
        $stmt->bind_param("sssss", $name, $email, $password, $role, $status);
        $stmt->execute();
    }

    public function testCannotInsertInvalidStatusEnum()
    {
        $conn = $this->getConnection();
        
        $this->expectException(\mysqli_sql_exception::class);
        
        $stmt = $conn->prepare("INSERT INTO users (name, email, password, role, status) VALUES (?, ?, ?, ?, ?)");
        $name = "Test User";
        $email = "test@gmail.com";
        $password = password_hash("Password123", PASSWORD_DEFAULT);
        $role = "user";
        $status = "suspended"; // Invalid status
        $stmt->bind_param("sssss", $name, $email, $password, $role, $status);
        $stmt->execute();
    }

    /* ============ PERFORMANCE TESTS ============ */

    public function testCanInsertMultipleUsersQuickly()
    {
        $conn = $this->getConnection();
        $stmt = $conn->prepare("INSERT INTO users (name, email, password, role, status) VALUES (?, ?, ?, ?, ?)");
        
        $password = password_hash("Password123", PASSWORD_DEFAULT);
        $role = "user";
        $status = "active";
        
        $startTime = microtime(true);
        
        for ($i = 1; $i <= 100; $i++) {
            $name = "User $i";
            $email = "user$i@gmail.com";
            $stmt->bind_param("sssss", $name, $email, $password, $role, $status);
            $stmt->execute();
        }
        
        $endTime = microtime(true);
        $executionTime = $endTime - $startTime;
        
        // Should complete in less than 2 seconds
        $this->assertLessThan(2, $executionTime, "Inserting 100 users should take less than 2 seconds");
        
        // Verify all were inserted
        $result = $conn->query("SELECT COUNT(*) as count FROM users");
        $row = $result->fetch_assoc();
        $this->assertEquals(100, $row['count']);
    }

    /* ============ INDEX TESTS ============ */

    public function testUsersTableHasPrimaryKey()
    {
        $result = $this->getConnection()->query("SHOW INDEXES FROM users WHERE Key_name = 'PRIMARY'");
        $this->assertEquals(1, $result->num_rows, "Users table should have a primary key");
    }

    public function testEventsTableHasPrimaryKey()
    {
        $result = $this->getConnection()->query("SHOW INDEXES FROM events WHERE Key_name = 'PRIMARY'");
        $this->assertEquals(1, $result->num_rows, "Events table should have a primary key");
    }

    public function testTicketsTableHasPrimaryKey()
    {
        $result = $this->getConnection()->query("SHOW INDEXES FROM tickets WHERE Key_name = 'PRIMARY'");
        $this->assertEquals(1, $result->num_rows, "Tickets table should have a primary key");
    }
}