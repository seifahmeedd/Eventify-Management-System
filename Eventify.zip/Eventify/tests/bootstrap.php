<?php
/**
 * PHPUnit Bootstrap for Eventify
 */

// Load Composer autoloader

// Load DatabaseTestCase
require_once __DIR__ . '/DatabaseTestCase.php';

echo "✓ Tests ready!\n";
require_once __DIR__ . '/../vendor/autoload.php';

// Set error reporting
error_reporting(E_ALL);
ini_set('display_errors', '1');

// Set timezone
date_default_timezone_set('UTC');

// Define test mode
define('TESTING', true);

echo "✓ Eventify tests ready to run!\n";