<?php

namespace Tests;

require_once __DIR__ . '/DatabaseTestCase.php';
require_once __DIR__ . '/../controllers/AdminController.php';
require_once __DIR__ . '/../models/User.php';
require_once __DIR__ . '/../models/Event.php';
require_once __DIR__ . '/../models/Ticket.php';
require_once __DIR__ . '/../models/Log.php';

use AdminController;
use User;
use Event;

/**
 * Tests for AdminController
 */
class AdminControllerTest extends DatabaseTestCase
{
    protected $adminController;
    protected $adminUserId;

    protected function setUp(): void
    {
        parent::setUp();
        
        // Clear all tables
        $conn = $this->getConnection();
        $conn->query("DELETE FROM tickets");
        $conn->query("DELETE FROM logs");
        $conn->query("DELETE FROM events");
        $conn->query("DELETE FROM users");
        
        // Create admin user for testing
        $this->adminUserId = User::create(
            $conn, 
            'Admin Test', 
            'admin@gmail.com', 
            'Admin123', 
            'admin', 
            'active'
        );
        
        // Set session for admin
        $_SESSION['user_id'] = $this->adminUserId;
        $_SESSION['user_name'] = 'Admin Test';
        $_SESSION['user_role'] = 'admin';
        
        // Initialize controller
        $this->adminController = new AdminController($conn);
    }

    protected function tearDown(): void
    {
        // Clear session
        $_SESSION = [];
        parent::tearDown();
    }

    /* ============ USER MANAGEMENT TESTS ============ */

    public function testAdminCanCreateUser()
    {
        $_SERVER['REQUEST_METHOD'] = 'POST';
        $_POST = [
            'name' => 'New User',
            'email' => 'newuser@gmail.com',
            'password' => 'Password123',
            'role' => 'user',
            'status' => 'active'
        ];

        // Capture output to prevent header errors
        ob_start();
        try {
            $this->adminController->addUser();
        } catch (\Exception $e) {
            // Expected redirect exception
        }
        ob_end_clean();

        // Verify user was created
        $user = User::findByEmail($this->getConnection(), 'newuser@gmail.com');
        $this->assertNotNull($user);
        $this->assertEquals('New User', $user['name']);
        $this->assertEquals('user', $user['role']);
    }

    public function testAdminCannotCreateUserWithInvalidEmail()
    {
        $_SERVER['REQUEST_METHOD'] = 'POST';
        $_POST = [
            'name' => 'Test User',
            'email' => 'invalid-email',
            'password' => 'Password123',
            'role' => 'user',
            'status' => 'active'
        ];

        ob_start();
        $this->adminController->addUser();
        $output = ob_get_clean();

        // Should show error message
        $this->assertStringContainsString('Invalid email format', $output);
        
        // User should not be created
        $user = User::findByEmail($this->getConnection(), 'invalid-email');
        $this->assertNull($user);
    }

    public function testAdminCannotCreateUserWithEmptyFields()
    {
        $_SERVER['REQUEST_METHOD'] = 'POST';
        $_POST = [
            'name' => '',
            'email' => 'test@gmail.com',
            'password' => '',
            'role' => 'user',
            'status' => 'active'
        ];

        ob_start();
        $this->adminController->addUser();
        $output = ob_get_clean();

        $this->assertStringContainsString('Name, email, and password are required', $output);
    }

    public function testAdminCanUpdateUser()
    {
        // Create a user first
        $userId = User::register($this->getConnection(), 'Original User', 'original@gmail.com', 'Password123');

        $_SERVER['REQUEST_METHOD'] = 'POST';
        $_POST = [
            'name' => 'Updated User',
            'email' => 'updated@gmail.com',
            'role' => 'admin',
            'status' => 'active'
        ];

        ob_start();
        try {
            $this->adminController->editUser($userId);
        } catch (\Exception $e) {
            // Expected redirect
        }
        ob_end_clean();

        // Verify update
        $user = User::getById($this->getConnection(), $userId);
        $this->assertEquals('Updated User', $user['name']);
        $this->assertEquals('updated@gmail.com', $user['email']);
        $this->assertEquals('admin', $user['role']);
    }

    public function testAdminCanDeleteUser()
    {
        $userId = User::register($this->getConnection(), 'Delete Me', 'delete@gmail.com', 'Password123');

        ob_start();
        try {
            $this->adminController->deleteUser($userId);
        } catch (\Exception $e) {
            // Expected redirect
        }
        ob_end_clean();

        // Verify deletion
        $user = User::getById($this->getConnection(), $userId);
        $this->assertNull($user);
    }

    public function testAdminCanViewAllUsers()
    {
        // Create multiple users
        User::register($this->getConnection(), 'User 1', 'user1@gmail.com', 'Password123');
        User::register($this->getConnection(), 'User 2', 'user2@gmail.com', 'Password123');

        ob_start();
        $this->adminController->users();
        $output = ob_get_clean();

        // Should display all users
        $this->assertStringContainsString('User 1', $output);
        $this->assertStringContainsString('User 2', $output);
    }

    /* ============ EVENT MANAGEMENT TESTS ============ */

    public function testAdminCanCreateEvent()
    {
        $_SERVER['REQUEST_METHOD'] = 'POST';
        $_POST = [
            'title' => 'Test Event',
            'description' => 'Test Description',
            'venue' => 'Test Venue',
            'date' => '2025-12-31',
            'time' => '18:00:00',
            'category' => 'concert',
            'capacity' => 100,
            'price' => 50.00,
            'status' => 'active',
            'has_seats' => 1
        ];

        ob_start();
        try {
            $this->adminController->addEvent();
        } catch (\Exception $e) {
            // Expected redirect
        }
        ob_end_clean();

        // Verify event was created
        $events = Event::all($this->getConnection());
        $this->assertCount(1, $events);
        $this->assertEquals('Test Event', $events[0]['title']);
    }

    public function testAdminCannotCreateEventWithInvalidData()
    {
        $_SERVER['REQUEST_METHOD'] = 'POST';
        $_POST = [
            'title' => '',
            'description' => 'Test',
            'venue' => '',
            'date' => '2025-12-31',
            'time' => '18:00:00',
            'category' => 'concert',
            'capacity' => -10,
            'price' => -5,
            'status' => 'active',
            'has_seats' => 1
        ];

        ob_start();
        $this->adminController->addEvent();
        $output = ob_get_clean();

        $this->assertStringContainsString('Invalid event data', $output);
    }

    public function testEventWithZeroCapacityIsMarkedSoldOut()
    {
        $_SERVER['REQUEST_METHOD'] = 'POST';
        $_POST = [
            'title' => 'Sold Out Event',
            'description' => 'Test',
            'venue' => 'Test Venue',
            'date' => '2025-12-31',
            'time' => '18:00:00',
            'category' => 'concert',
            'capacity' => 0,
            'price' => 50.00,
            'status' => 'active',
            'has_seats' => 1
        ];

        ob_start();
        try {
            $this->adminController->addEvent();
        } catch (\Exception $e) {
            // Expected redirect
        }
        ob_end_clean();

        $events = Event::all($this->getConnection());
        $this->assertEquals('sold_out', $events[0]['status']);
    }

    public function testAdminCanUpdateEvent()
    {
        $eventId = Event::create(
            $this->getConnection(),
            'Original Event',
            'Description',
            'Venue',
            '2025-12-31',
            '18:00:00',
            'concert',
            100,
            50.00,
            'active',
            1
        );

        $_SERVER['REQUEST_METHOD'] = 'POST';
        $_POST = [
            'title' => 'Updated Event',
            'description' => 'New Description',
            'venue' => 'New Venue',
            'date' => '2025-12-31',
            'time' => '20:00:00',
            'category' => 'sports',
            'capacity' => 200,
            'price' => 75.00,
            'status' => 'active',
            'has_seats' => 1
        ];

        ob_start();
        try {
            $this->adminController->editEvent($eventId);
        } catch (\Exception $e) {
            // Expected redirect
        }
        ob_end_clean();

        $event = Event::getById($this->getConnection(), $eventId);
        $this->assertEquals('Updated Event', $event['title']);
        $this->assertEquals(200, $event['capacity']);
    }

    public function testAdminCanDeleteEvent()
    {
        $eventId = Event::create(
            $this->getConnection(),
            'Delete Me',
            'Description',
            'Venue',
            '2025-12-31',
            '18:00:00',
            'concert',
            100,
            50.00,
            'active',
            1
        );

        ob_start();
        try {
            $this->adminController->deleteEvent($eventId);
        } catch (\Exception $e) {
            // Expected redirect
        }
        ob_end_clean();

        $event = Event::getById($this->getConnection(), $eventId);
        $this->assertNull($event);
    }

    /* ============ DASHBOARD TESTS ============ */

    public function testAdminCanViewDashboard()
    {
        // Create test data
        User::register($this->getConnection(), 'User 1', 'user1@gmail.com', 'Password123');
        Event::create($this->getConnection(), 'Event 1', 'Desc', 'Venue', '2025-12-31', '18:00', 'concert', 100, 50, 'active', 1);

        ob_start();
        $this->adminController->dashboard();
        $output = ob_get_clean();

        // Should show statistics
        $this->assertNotEmpty($output);
    }

    /* ============ HELPER METHOD TESTS ============ */

    public function testFormatEGPFormatsCorrectly()
    {
        $reflection = new \ReflectionClass($this->adminController);
        $method = $reflection->getMethod('formatEGP');
        $method->setAccessible(true);

        $result = $method->invoke($this->adminController, 1234.5);
        $this->assertEquals('1,234.50 EGP', $result);

        $result = $method->invoke($this->adminController, 100);
        $this->assertEquals('100.00 EGP', $result);
    }
}