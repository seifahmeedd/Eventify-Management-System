<?php
session_start();
require_once 'db.php';                // Database connection

// Require controllers
require_once 'controllers/UserController.php';

// Require models
require_once 'models/User.php';
require_once 'models/Event.php';
require_once 'models/Ticket.php';
require_once 'models/Log.php'; // ✅ Needed for LogObserver

// ✅ Attach LogObserver globally
$logObserver = new LogObserver($conn);
User::attach($logObserver);
Event::attach($logObserver);
Ticket::attach($logObserver);

// Instantiate controller
$controller = new UserController($conn);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Handle login attempt
    $email    = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    try {
        $controller->login($email, $password);
    } catch (Exception $e) {
        // Store error message in session and reload login form
        $_SESSION['error'] = $e->getMessage();
        header("Location: users.php?action=login");
        exit;
    }
} else {
    // Show login form
    try {
        $controller->showLogin();
    } catch (Exception $e) {
        // Catch unexpected errors when rendering the form
        $_SESSION['error'] = "Unable to load login form. Please try again.";
        header("Location: users.php?action=login");
        exit;
    }
}