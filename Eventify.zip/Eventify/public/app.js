/* ===========================
   Helpers
   =========================== */
function getPageName() {
  return window.location.pathname.split("/").pop();
}

async function fetchJSON(url) {
  try {
    const res = await fetch(url, { credentials: "include" });
    if (!res.ok) throw new Error("Network error");
    return await res.json();
  } catch (err) {
    console.error("Fetch failed:", err);
    return [];
  }
}

/* ===========================
   Event Rendering
   =========================== */
async function renderEvents() {
  const events = await fetchJSON("events.php?action=listJson");
  const grid = document.querySelector(".grid");
  if (!grid) return;

  grid.innerHTML = events.map(e => `
    <div class="card event-card center" data-category="${e.category}">
      <div class="event-emoji">${e.emoji || "🎫"}</div>
      <h3>${e.title}</h3>
      <p class="muted">${e.date} • ${e.venue}</p>
      <a href="events.php?action=details&id=${e.id}" class="btn primary">View Details</a>
    </div>
  `).join("");
}

async function renderEventDetails() {
  const params = new URLSearchParams(window.location.search);
  const id = params.get("id");
  if (!id) return;

  const event = await fetchJSON(`events.php?action=detailsJson&id=${id}`);
  if (!event) return;

  const titleEl = document.querySelector(".left h2");
  const infoEl = document.querySelector(".left p.muted");
  const priceEl = document.querySelector(".right h2");

  if (titleEl) titleEl.textContent = event.title;
  if (infoEl) infoEl.textContent = `${event.venue} • ${event.date}`;
  if (priceEl) priceEl.textContent = `${event.price} EGP`;
}

/* ===========================
   Dashboard Section Toggle
   =========================== */
function showSection(sectionId) {
  document.querySelectorAll(".dashboard-section").forEach(s => s.classList.remove("active"));
  const section = document.getElementById(sectionId);
  if (section) section.classList.add("active");

  document.querySelectorAll(".sidenav a").forEach(link => link.classList.remove("active"));
  const activeLink = document.querySelector(`.sidenav a[href="#${sectionId}"]`);
  if (activeLink) activeLink.classList.add("active");
}

/* ===========================
   Checkout Rendering
   =========================== */
async function renderCheckout() {
  const cart = await fetchJSON("tickets.php?action=getCartJson");
  const summary = document.querySelector(".left .card");
  if (!summary) return;

  summary.innerHTML = cart.map(item => `
    <div class="row">
      <div>
        <h4>${item.title}</h4>
        <p class="muted">${item.qty} × Ticket</p>
      </div>
      <div>${item.price * item.qty} EGP</div>
    </div>
  `).join("");
}

/* ===========================
   Ticket Rendering
   =========================== */
async function renderTicket(ticketId) {
  const ticket = await fetchJSON(`tickets.php?action=viewJson&id=${ticketId}`);
  if (!ticket) return;

  document.querySelector(".ticket-card h2").textContent = ticket.event;
  document.querySelector(".ticket-info").innerHTML = `
    <div><strong>Seat:</strong> ${ticket.seat}</div>
    <div><strong>Time:</strong> ${ticket.time}</div>
    <div><strong>Price:</strong> ${ticket.price} EGP</div>
    <div><strong>Entry Code:</strong> ${ticket.code}</div>
  `;
  document.querySelector(".qr-area img").src =
    `https://api.qrserver.com/v1/create-qr-code/?data=${ticket.code}&size=130x130`;
}

/* ===========================
   Dashboard Rendering
   =========================== */
async function renderDashboard() {
  const user = await fetchJSON("users.php?action=dashboardDataJson");
  const tickets = await fetchJSON("tickets.php?action=listUserTicketsJson");
  const orders = await fetchJSON("tickets.php?action=listUserOrdersJson");

  const userNameEl = document.getElementById("userName");
  if (userNameEl) {
    if (user.name) userNameEl.textContent = user.name;
    else if (user.email) userNameEl.textContent = user.email;
  }

  const ticketsTable = document.getElementById("ticketsTable");
  if (ticketsTable) {
    ticketsTable.innerHTML = tickets.map(t => `
      <tr>
        <td>${t.event}</td>
        <td>${t.date}</td>
        <td>${t.seat}</td>
        <td>${t.code}</td>
      </tr>
    `).join("");
  }

  const ordersTable = document.getElementById("ordersTable");
  if (ordersTable) {
    ordersTable.innerHTML = orders.map(o => `
      <tr>
        <td>${o.id}</td>
        <td>${o.event}</td>
        <td>${o.date}</td>
        <td>${o.total} EGP</td>
        <td><span class="tag">${o.status}</span></td>
      </tr>
    `).join("");
  }
}

/* ===========================
   Admin Dashboard Rendering
   =========================== */
async function renderAdminDashboard() {
  const events = await fetchJSON("admin.php?action=eventsJson");
  const table = document.getElementById("adminEventsTable");
  if (table) {
    table.innerHTML = events.map(e => `
      <tr>
        <td>${e.id}</td>
        <td>${e.title}</td>
        <td>${e.date}</td>
        <td>${e.venue}</td>
        <td>${e.sold || 0}/${e.capacity || 0}</td>
        <td><span class="tag">${e.status || "Active"}</span></td>
        <td>
          <button class="btn">Edit</button>
          <button class="btn">View</button>
        </td>
      </tr>
    `).join("");
  }

  const statsGrid = document.getElementById("adminStatsGrid");
  if (statsGrid) {
    const totalTickets = events.reduce((sum, e) => sum + (e.capacity || 0), 0);
    const soldTickets = events.reduce((sum, e) => sum + (e.sold || 0), 0);
    const revenue = events.reduce((sum, e) => sum + (e.revenue || 0), 0);

    const stats = [
      { value: soldTickets, label: "Total Tickets Sold" },
      { value: events.length, label: "Active Events" },
      { value: `${revenue} EGP`, label: "Total Revenue" }
    ];

    statsGrid.innerHTML = stats.map(s => `
      <div class="card center">
        <h3>${s.value}</h3>
        <p class="muted">${s.label}</p>
      </div>
    `).join("");
  }
}

/* ===========================
   Event Search Functionality
   =========================== */
document.addEventListener("DOMContentLoaded", () => {
  const searchInput = document.getElementById("searchInput");
  if (!searchInput) return;

  searchInput.addEventListener("input", () => {
    const query = searchInput.value.toLowerCase();
    const cards = document.querySelectorAll(".event-card");
    const grid = document.querySelector(".grid");

    let anyVisible = false;

    cards.forEach(card => {
      const title = card.querySelector("h3").textContent.toLowerCase();
      if (title.includes(query)) {
        card.style.display = ""; // show
        anyVisible = true;
      } else {
        card.style.display = "none"; // hide
      }
    });

    // ✅ Remove old message
    const oldMessage = document.getElementById("noResults");
    if (oldMessage) oldMessage.remove();

    // ✅ Show plain text message if no cards are visible
    if (!anyVisible) {
      const noResults = document.createElement("p"); // use <p> instead of div/card
      noResults.id = "noResults";
      noResults.textContent = "No matching events found.";
      grid.appendChild(noResults);
    }
  });
});