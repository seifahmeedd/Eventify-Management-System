<?php
require_once __DIR__ . '/../models/Event.php';
require_once __DIR__ . '/../models/User.php';
require_once __DIR__ . '/../models/Ticket.php';
require_once __DIR__ . '/../models/Log.php';

class AdminController {
    private $conn;
    private $logObserver;

    public function __construct($conn) {
        $this->conn = $conn;
        // ✅ Attach LogObserver for error logging
        $this->logObserver = new LogObserver($conn);
    }

    /* ---------------- HELPER: REDIRECT ---------------- */
    private function redirect($url) {
        header("Location: $url");
        exit;
    }

    /* ---------------- HELPER: FORMAT CURRENCY ---------------- */
    private function formatEGP($amount) {
        return number_format((float)$amount, 2) . " EGP";
    }

    /* ---------------- ADMIN: DASHBOARD ---------------- */
    public function dashboard() {
        $events       = Event::getActiveEvents($this->conn);
        $totalUsers   = User::count($this->conn);
        $totalTickets = Ticket::count($this->conn);
        $activeEvents = Event::countActive($this->conn);
        $totalRevenue = Ticket::getTotalRevenue($this->conn);

        $totalRevenueFormatted = $this->formatEGP($totalRevenue);

        include __DIR__ . '/../views/admin/dashboard.php';
    }

    /* ---------------- ADMIN: EVENTS CRUD ---------------- */
    public function events() {
        $events = Event::all($this->conn);
        include __DIR__ . '/../views/admin/events.php';
    }

    public function addEvent() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $title       = trim($_POST['title']);
            $description = trim($_POST['description']);
            $venue       = trim($_POST['venue']);
            $date        = $_POST['date'];
            $time        = $_POST['time'];
            $category    = $_POST['category'];
            $capacity    = (int)$_POST['capacity'];
            $price       = (float)$_POST['price'];
            $status      = $_POST['status'];
            $hasSeats    = isset($_POST['has_seats']) ? (int)$_POST['has_seats'] : 1;

            // ✅ Validation
            if (empty($title) || empty($venue) || $capacity < 0 || $price < 0) {
                $error = "Invalid event data. Title, venue, capacity, and price are required.";
                include __DIR__ . '/../views/admin/addEvent.php';
                return;
            }
            if ($capacity === 0) {
                $status = 'sold_out';
            }

            try {
                Event::create($this->conn, $title, $description, $venue, $date, $time, $category, $capacity, $price, $status, $hasSeats,);
                $this->redirect("admin.php?action=events&msg=added");
            } catch (Exception $e) {
                $this->logObserver->update($this, "Error adding event: " . $e->getMessage());
                $error = $e->getMessage();
                include __DIR__ . '/../views/admin/addEvent.php';
            }
        } else {
            include __DIR__ . '/../views/admin/addEvent.php';
        }
    }

    public function editEvent($id) {
        $id = (int)$id;
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $title       = trim($_POST['title'] ?? '');
            $description = trim($_POST['description'] ?? '');
            $venue       = trim($_POST['venue'] ?? '');
            $date        = $_POST['date'] ?? '';
            $time        = $_POST['time'] ?? '';
            $category    = $_POST['category'] ?? '';
            $capacity    = (int)($_POST['capacity'] ?? 0);
            $price       = (float)($_POST['price'] ?? 0);
            $status      = $_POST['status'] ?? 'active';
            $hasSeats    = isset($_POST['has_seats']) ? (int)$_POST['has_seats'] : 1;

            if ($capacity === 0) {
                $status = 'sold_out';
            }

            try {
                Event::update($this->conn, $id, $title, $description, $venue, $date, $time, $category, $capacity, $price, $status, $hasSeats);
                $this->redirect("admin.php?action=events&msg=updated");
            } catch (Exception $e) {
                $this->logObserver->update($this, "Error editing event: " . $e->getMessage());
                $error = $e->getMessage();
                $event = Event::getById($this->conn, $id);
                include __DIR__ . '/../views/admin/editEvent.php';
            }
        } else {
            $event = Event::getById($this->conn, $id);
            if (!$event) {
                $this->redirect("admin.php?action=events&msg=notfound");
            }
            include __DIR__ . '/../views/admin/editEvent.php';
        }
    }

    public function deleteEvent($id) {
        $id = (int)$id;
        try {
            if (Event::delete($this->conn, $id)) {
                $this->redirect("admin.php?action=events&msg=deleted");
            } else {
                $this->redirect("admin.php?action=events&msg=deleteerror");
            }
        } catch (Exception $e) {
            $this->logObserver->update($this, "Error deleting event: " . $e->getMessage());
            $this->redirect("admin.php?action=events&msg=deleteerror");
        }
    }

    /* ---------------- ADMIN: USERS CRUD ---------------- */
    public function users() {
        $users = User::all($this->conn);
        include __DIR__ . '/../views/admin/users.php';
    }

    public function addUser() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $name     = trim($_POST['name']);
            $email    = trim($_POST['email']);
            $password = $_POST['password'];
            $role     = $_POST['role'];
            $status   = $_POST['status'];

            // ✅ Validation
            if (empty($name) || empty($email) || empty($password)) {
                $error = "Name, email, and password are required.";
                include __DIR__ . '/../views/admin/addUser.php';
                return;
            }
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $error = "Invalid email format.";
                include __DIR__ . '/../views/admin/addUser.php';
                return;
            }

            try {
                User::create($this->conn, $name, $email, $password, $role, $status);
                $this->redirect("admin.php?action=users&msg=created");
            } catch (Exception $e) {
                $this->logObserver->update($this, "Error adding user: " . $e->getMessage());
                $error = $e->getMessage();
                include __DIR__ . '/../views/admin/addUser.php';
            }
        } else {
            include __DIR__ . '/../views/admin/addUser.php';
        }
    }

    public function editUser($id) {
        $id = (int)$id;
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $name   = trim($_POST['name']);
            $email  = trim($_POST['email']);
            $role   = $_POST['role'];
            $status = $_POST['status'];

            try {
                User::update($this->conn, $id, $name, $email, $role, $status);
                $this->redirect("admin.php?action=users&msg=updated");
            } catch (Exception $e) {
                $this->logObserver->update($this, "Error editing user: " . $e->getMessage());
                $error = $e->getMessage();
                $user = User::getById($this->conn, $id);
                include __DIR__ . '/../views/admin/editUser.php';
            }
        } else {
            $user = User::getById($this->conn, $id);
            if (!$user) {
                $this->redirect("admin.php?action=users&msg=notfound");
            }
            include __DIR__ . '/../views/admin/editUser.php';
        }
    }

       public function deleteUser($id) {
        $id = (int)$id;
        try {
            if (User::delete($this->conn, $id)) {
                $this->redirect("admin.php?action=users&msg=deleted");
            } else {
                $this->redirect("admin.php?action=users&msg=deleteerror");
            }
        } catch (Exception $e) {
            // ✅ Log the error for traceability
            $this->logObserver->update($this, "Error deleting user: " . $e->getMessage());
            $this->redirect("admin.php?action=users&msg=deleteerror");
        }
    }
}