<?php
require_once __DIR__ . '/../models/User.php';
require_once __DIR__ . '/../models/Ticket.php';
require_once __DIR__ . '/../models/Log.php';

class UserController {
    private $conn;
    private $logObserver;

    public function __construct($conn) {
        $this->conn = $conn;
        // Attach LogObserver for logging
        $this->logObserver = new LogObserver($conn);
    }

    private function redirect($url) {
        header("Location: $url");
        exit;
    }

    private function formatEGP($amount) {
        return number_format((float)$amount, 2) . " EGP";
    }

    /* ---------------- AUTH ---------------- */
    public function showLogin($error = "") {
        include __DIR__ . '/../views/users/login.php';
    }

    public function showRegister($error = "") {
        include __DIR__ . '/../views/users/register.php';
    }

    public function login($email, $password) {
    if (empty($email) || empty($password)) {
        $this->showLogin("Email and password are required.");
        return;
    }

    try {
        $user = User::login($this->conn, $email, $password);

        if ($user) {
            // ✅ Block banned users before login
            if ($user['status'] === 'banned') {
                $this->logObserver->update(
                    (object)[ 'user_id' => $user['id'], 'entity' => 'User', 'label' => $email, 'actor' => 'System' ],
                    "Login blocked — user is banned",
                    "warning"
                );
                $this->showLogin("This account is banned.");
                return;
            }

            // ✅ Set session
            $_SESSION['user_id']   = $user['id'];
            $_SESSION['user_name'] = $user['name'];
            $_SESSION['user_role'] = strtolower($user['role']);

            // ✅ Log successful login
            $this->logObserver->update(
                (object)[ 'user_id' => $user['id'], 'entity' => 'User', 'label' => $user['name'], 'actor' => $user['name'] ],
                "Logged in",
                "success"
            );

            if ($_SESSION['user_role'] === 'admin') {
                $this->redirect("admin.php?action=dashboard");
            } else {
                $this->redirect("users.php?action=dashboard");
            }
        } else {
            // ✅ Wrong email or password
            $this->logObserver->update(
                (object)[ 'user_id' => null, 'entity' => 'User', 'label' => $email, 'actor' => 'System' ],
                "Failed login attempt",
                "warning"
            );
            $this->showLogin("Wrong email or password.");
        }
    } catch (Exception $e) {
        // ✅ System error
        $this->logObserver->update(
            (object)[ 'user_id' => null, 'entity' => 'User', 'label' => $email, 'actor' => 'System' ],
            "Login error: " . $e->getMessage(),
            "error"
        );
        $this->showLogin("Login failed: " . htmlspecialchars($e->getMessage()));
    }
}

    public function register($username, $email, $password, $confirmPassword) {
    // Validation
    if (empty($username) || empty($email) || empty($password) || empty($confirmPassword)) {
        $this->showRegister("All fields are required.");
        return;
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $this->showRegister("Invalid email format.");
        return;
    }
    if ($password !== $confirmPassword) {
        $this->showRegister("Passwords do not match.");
        return;
    }
    if (strlen($password) < 8) {
        $this->showRegister("Password must be at least 8 characters.");
        return;
    }
    if (!preg_match('/^(?=.*[A-Z])(?=.*\d).+$/', $password)) {
        $this->showRegister("Password must contain at least one uppercase letter and one number.");
        return;
    }

    try {
        // ❌ Don’t hash here — let the model do it
        User::register($this->conn, $username, $email, $password);

        // Log successful registration
        $this->logObserver->update(
            (object)[ 'user_id' => null, 'entity' => 'User', 'label' => $email, 'actor' => 'System' ],
            "Registered new account",
            "success"
        );

        $this->redirect("users.php?action=login&msg=registered");
    } catch (Exception $e) {
        $this->logObserver->update(
            (object)[ 'user_id' => null, 'entity' => 'User', 'label' => $email, 'actor' => 'System' ],
            "Registration error: " . $e->getMessage(),
            "error"
        );
        $this->showRegister(htmlspecialchars($e->getMessage()));
    }
}

    public function dashboard() {
        $userId = $_SESSION['user_id'] ?? null;
        if (!$userId) {
            $this->redirect("users.php?action=login");
        }

        try {
            $recentTickets = Ticket::getRecentByUser($this->conn, $userId);
            $user          = User::getById($this->conn, $userId);
            $tickets       = Ticket::getByUserId($this->conn, $userId);
            $totalSpent    = Ticket::getTotalSpentByUser($this->conn, $userId);
            $ticketCount   = Ticket::countByUser($this->conn, $userId);

            $totalSpentFormatted = $this->formatEGP($totalSpent);

            include __DIR__ . '/../views/users/dashboard.php';
        } catch (Exception $e) {
            // Log dashboard error
            $this->logObserver->update(
                (object)[ 'user_id' => $userId, 'entity' => 'User', 'label' => 'Dashboard', 'actor' => $_SESSION['user_name'] ?? 'System' ],
                "Dashboard error: " . $e->getMessage(),
                "error"
            );
            $_SESSION['error'] = "Unable to load dashboard: " . htmlspecialchars($e->getMessage());
            $this->redirect("users.php?action=login");
        }
    }
}