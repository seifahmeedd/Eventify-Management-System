<?php
require_once __DIR__ . '/../models/Log.php';

class LogController {
    private $conn;
    private $logObserver;

    public function __construct($conn) {
        $this->conn = $conn;
        // ✅ Attach LogObserver for error logging
        $this->logObserver = new LogObserver($conn);
    }

    /* ---------------- ADMIN: SHOW ALL LOGS ---------------- */
    public function index() {
        try {
            $logs = Log::all($this->conn); // delegate to model
            include __DIR__ . '/../views/admin/logs.php';
        } catch (Exception $e) {
            // ✅ Log the error for traceability
            $this->logObserver->update($this, "Error loading logs: " . $e->getMessage());
            $error = "Unable to load logs: " . htmlspecialchars($e->getMessage());
            include __DIR__ . '/../views/admin/logs.php';
        }
    }
}