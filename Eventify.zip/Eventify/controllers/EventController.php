<?php
require_once __DIR__ . '/../models/Event.php';
require_once __DIR__ . '/../models/Log.php';

class EventController {
    private $conn;
    private $logObserver;

    public function __construct($conn) {
        $this->conn = $conn;
        // ✅ Attach LogObserver for error logging
        $this->logObserver = new LogObserver($conn);
    }

    /* ---------------- HELPER: FORMAT CURRENCY ---------------- */
    private function formatEGP($amount) {
        return number_format((float)$amount, 2) . " EGP";
    }

    private function formatEvents(array $events) {
        foreach ($events as &$ev) {
            $ev['price_formatted'] = $this->formatEGP($ev['price']);
        }
        return $events;
    }

    /* ---------------- PUBLIC: EVENTS LIST (HOME) ---------------- */
    public function home() {
        try {
            $events = Event::getActiveEvents($this->conn);
            $events = $this->formatEvents($events);
            include __DIR__ . '/../views/home.php';
        } catch (Exception $e) {
            $this->logObserver->update($this, "Error loading home events: " . $e->getMessage());
            echo "<div class='alert error'>Unable to load events: " . htmlspecialchars($e->getMessage()) . "</div>";
        }
    }

    /* ---------------- PUBLIC: EVENTS LIST ---------------- */
    public function listEvents() {
        try {
            $events = Event::all($this->conn);
            $events = $this->formatEvents($events);
            include __DIR__ . '/../views/events/events.php';
        } catch (Exception $e) {
            $this->logObserver->update($this, "Error loading events list: " . $e->getMessage());
            echo "<div class='alert error'>Unable to load events list: " . htmlspecialchars($e->getMessage()) . "</div>";
        }
    }

    /* ---------------- PUBLIC: EVENT DETAILS ---------------- */
    public function showDetails($id) {
        $id = (int)$id;
        if ($id <= 0) {
            echo "<div class='alert error'>Invalid event ID.</div>";
            return;
        }

        try {
            $event = Event::getById($this->conn, $id);
            if (!$event || $event['status'] !== 'active') {
                echo "<div class='alert error'>Event not found or unavailable.</div>";
                return;
            }
            $event['price_formatted'] = $this->formatEGP($event['price']);
            include __DIR__ . '/../views/events/details.php';
        } catch (Exception $e) {
            $this->logObserver->update($this, "Error loading event details for ID {$id}: " . $e->getMessage());
            echo "<div class='alert error'>Unable to load event details: " . htmlspecialchars($e->getMessage()) . "</div>";
        }
    }
}