<?php
require_once __DIR__ . '/../models/Ticket.php';
require_once __DIR__ . '/../models/Event.php';
require_once __DIR__ . '/../models/Log.php';

class TicketController {
    private $conn;
    private $logObserver;

    public function __construct($conn) {
        $this->conn = $conn;
        // ✅ Attach LogObserver for error logging
        $this->logObserver = new LogObserver($conn);
    }

    /* ---------------- HELPER: FORMAT CURRENCY ---------------- */
    private function formatEGP($amount) {
        return number_format((float)$amount, 2) . " EGP";
    }

    /* ---------------- USER: VIEW SINGLE TICKET ---------------- */
    public function view($ticketId) {
        $ticketId = (int)$ticketId;
        if ($ticketId <= 0) {
            $_SESSION['error'] = "Invalid ticket ID.";
            header("Location: tickets.php?action=list");
            exit;
        }

        try {
            $ticket = Ticket::getById($this->conn, $ticketId);
            if (!$ticket) {
                header("Location: tickets.php?action=list&msg=notfound");
                exit;
            }

            // Ownership check
            if (isset($_SESSION['user_id']) && $ticket['user_id'] != $_SESSION['user_id']) {
                header("Location: tickets.php?action=list&msg=forbidden");
                exit;
            }

            $ticket['price_formatted'] = $this->formatEGP($ticket['price']);
            include __DIR__ . '/../views/tickets/ticket.php';
        } catch (Exception $e) {
            $this->logObserver->update($this, "Error viewing ticket ID {$ticketId}: " . $e->getMessage());
            $_SESSION['error'] = "Unable to load ticket: " . htmlspecialchars($e->getMessage());
            header("Location: tickets.php?action=list");
            exit;
        }
    }

    /* ---------------- USER: CHECKOUT ---------------- */
    public function checkout($eventId) {
        $eventId = (int)$eventId;

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $quantity = (int)($_POST['quantity'] ?? 1);
            $userId   = $_SESSION['user_id'] ?? null;

            if (!$userId) {
                header("Location: users.php?action=login&msg=loginrequired");
                exit;
            }

            // ✅ Validation
            if ($quantity <= 0) {
                $error = "Quantity must be at least 1.";
                $event = Event::getById($this->conn, $eventId);
                if ($event) {
                    $event['price_formatted'] = $this->formatEGP($event['price']);
                }
                include __DIR__ . '/../views/tickets/checkout.php';
                return;
            }

            try {
                $ticketIds = Ticket::purchase($this->conn, $eventId, $userId, $quantity);
                $ids = implode(',', $ticketIds);
                header("Location: tickets.php?action=confirmation&event_id=$eventId&ticket_ids=$ids");
                exit;
            } catch (Exception $e) {
                $this->logObserver->update($this, "Error during checkout for event {$eventId}: " . $e->getMessage());
                $error = htmlspecialchars($e->getMessage());
                $event = Event::getById($this->conn, $eventId);
                if ($event) {
                    $event['price_formatted'] = $this->formatEGP($event['price']);
                }
                include __DIR__ . '/../views/tickets/checkout.php';
            }
        } else {
            try {
                $event = Event::getById($this->conn, $eventId);
                if (!$event) {
                    $_SESSION['error'] = "Event not found.";
                    header("Location: events.php?action=list");
                    exit;
                }
                $event['price_formatted'] = $this->formatEGP($event['price']);
                include __DIR__ . '/../views/tickets/checkout.php';
            } catch (Exception $e) {
                $this->logObserver->update($this, "Error loading checkout for event {$eventId}: " . $e->getMessage());
                $_SESSION['error'] = "Unable to load checkout: " . htmlspecialchars($e->getMessage());
                header("Location: events.php?action=list");
                exit;
            }
        }
    }

    /* ---------------- USER: CONFIRMATION ---------------- */
    public function confirmation($eventId) {
        $eventId = (int)$eventId;
        $userId  = $_SESSION['user_id'] ?? null;

        if (!$userId) {
            $_SESSION['error'] = "You must be logged in to view confirmation.";
            header("Location: users.php?action=login");
            exit;
        }

        try {
            $ticketIds = isset($_GET['ticket_ids']) ? array_filter(explode(',', $_GET['ticket_ids']), 'is_numeric') : [];
            $event = Event::getById($this->conn, $eventId);
            if (!$event) {
                $_SESSION['error'] = "Event not found.";
                header("Location: events.php?action=list");
                exit;
            }
            $event['price_formatted'] = $this->formatEGP($event['price']);

            $tickets = !empty($ticketIds)
                ? Ticket::getByIds($this->conn, $ticketIds, $userId)
                : Ticket::getByUserAndEvent($this->conn, $userId, $eventId);

            if (empty($tickets)) {
                $_SESSION['error'] = "No tickets found for this event.";
                header("Location: events.php?action=list");
                exit;
            }

            $totalSpent = array_sum(array_column($tickets, 'price'));
            $totalSpentFormatted = $this->formatEGP($totalSpent);

            foreach ($tickets as &$ticket) {
                $ticket['price_formatted'] = $this->formatEGP($ticket['price']);
            }

            include __DIR__ . '/../views/tickets/confirmation.php';
        } catch (Exception $e) {
            $this->logObserver->update($this, "Error loading confirmation for event {$eventId}: " . $e->getMessage());
            $_SESSION['error'] = "Unable to load confirmation: " . htmlspecialchars($e->getMessage());
            header("Location: events.php?action=list");
            exit;
        }
    }
}