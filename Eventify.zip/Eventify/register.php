<?php
session_start();
require_once 'db.php';                // Database connection

// Require controllers
require_once 'controllers/UserController.php';

// Require models
require_once 'models/User.php';
require_once 'models/Event.php';
require_once 'models/Ticket.php';
require_once 'models/Log.php'; // ✅ Needed for LogObserver

// ✅ Attach LogObserver globally
$logObserver = new LogObserver($conn);
User::attach($logObserver);
Event::attach($logObserver);
Ticket::attach($logObserver);

// Instantiate controller
$controller = new UserController($conn);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Handle registration attempt
    $username        = trim($_POST['username'] ?? '');
    $email           = trim($_POST['email'] ?? '');
    $password        = $_POST['password'] ?? '';
    $confirmPassword = $_POST['confirm_password'] ?? '';

    try {
        $controller->register($username, $email, $password, $confirmPassword);
    } catch (Exception $e) {
        // Store error message in session and reload the form
        $_SESSION['error'] = $e->getMessage();
        header("Location: users.php?action=register");
        exit;
    }
} else {
    // Show registration form
    try {
        $controller->showRegister();
    } catch (Exception $e) {
        // Catch unexpected errors when rendering the form
        $_SESSION['error'] = "Unable to load registration form. Please try again.";
        header("Location: users.php?action=register");
        exit;
    }
}