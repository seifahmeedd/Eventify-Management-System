<?php
ob_start();
session_start();
require_once 'db.php';

// Require controllers
require_once 'controllers/UserController.php';

// Require models
require_once 'models/User.php';
require_once 'models/Ticket.php';
require_once 'models/Event.php';
require_once 'models/Log.php'; // ✅ Needed for LogObserver

// ✅ Attach LogObserver globally
$logObserver = new LogObserver($conn);
User::attach($logObserver);
Ticket::attach($logObserver);
Event::attach($logObserver);

// Instantiate controller
$controller = new UserController($conn);

// Get action from query string
$action = $_GET['action'] ?? 'dashboard';

// Helper: redirect with error
function redirectWithError($message, $location = "users.php?action=login") {
    $_SESSION['error'] = $message;
    header("Location: $location");
    exit;
}

try {
    switch ($action) {
        /* ---------------- LOGIN ---------------- */
        case 'login':
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                $email    = trim($_POST['email'] ?? '');
                $password = $_POST['password'] ?? '';
                $controller->login($email, $password);
            } else {
                $controller->showLogin($_SESSION['error'] ?? "");
                unset($_SESSION['error']);
            }
            break;

        /* ---------------- REGISTER ---------------- */
        case 'register':
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                $name            = trim($_POST['name'] ?? '');
                $email           = trim($_POST['email'] ?? '');
                $password        = $_POST['password'] ?? '';
                $confirmPassword = $_POST['confirm_password'] ?? '';
                $controller->register($name, $email, $password, $confirmPassword);
            } else {
                $controller->showRegister($_SESSION['error'] ?? "");
                unset($_SESSION['error']);
            }
            break;

        /* ---------------- DASHBOARD ---------------- */
        case 'dashboard':
            if (!isset($_SESSION['user_id'])) {
                header("Location: users.php?action=login"); // ✅ consistent redirect
                exit;
            }
            if (($_SESSION['user_role'] ?? 'user') === 'admin') {
                header("Location: admin.php?action=dashboard");
                exit;
            }
            $controller->dashboard();
            break;

        /* ---------------- LOGOUT ---------------- */
        case 'logout':
            if (isset($_SESSION['user_id'])) {
                $logObserver->update((object)[
                    'id'     => $_SESSION['user_id'],
                    'entity' => 'User',
                    'label'  => $_SESSION['user_name'] ?? 'Unknown',
                    'actor'  => $_SESSION['user_name'] ?? 'System'
                ], "Logged out");
            }
            session_unset();
            session_destroy();
            header("Location: users.php?action=login");
            exit;

        /* ---------------- JSON ENDPOINTS ---------------- */
        case 'dashboardDataJson':
            header('Content-Type: application/json');
            try {
                $userId = $_SESSION['user_id'] ?? null;
                echo json_encode($userId ? User::getById($conn, $userId) : null);
            } catch (Exception $e) {
                http_response_code(500);
                echo json_encode(['error' => $e->getMessage()]);
            }
            exit;

        case 'listUserTicketsJson':
            header('Content-Type: application/json');
            try {
                $userId = $_SESSION['user_id'] ?? null;
                echo json_encode($userId ? Ticket::getByUserId($conn, $userId) : []);
            } catch (Exception $e) {
                http_response_code(500);
                echo json_encode(['error' => $e->getMessage()]);
            }
            exit;

        case 'listUserOrdersJson':
            header('Content-Type: application/json');
            try {
                $userId = $_SESSION['user_id'] ?? null;
                echo json_encode($userId ? Ticket::getRecentByUser($conn, $userId) : []);
            } catch (Exception $e) {
                http_response_code(500);
                echo json_encode(['error' => $e->getMessage()]);
            }
            exit;

        /* ---------------- DEFAULT ---------------- */
        default:
            if (!isset($_SESSION['user_id'])) {
                header("Location: users.php?action=login"); // ✅ consistent redirect
                exit;
            }
            if (($_SESSION['user_role'] ?? 'user') === 'admin') {
                header("Location: admin.php?action=dashboard");
                exit;
            }
            $controller->dashboard();
            break;
    }
} catch (Exception $e) {
    redirectWithError($e->getMessage(), "users.php?action=login");
}