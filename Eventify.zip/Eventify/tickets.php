<?php
session_start();
require_once 'db.php';

// Require controllers
require_once 'controllers/TicketController.php';

// Require models
require_once 'models/Ticket.php';
require_once 'models/Event.php';
require_once 'models/User.php';
require_once 'models/Log.php'; // ✅ Needed for LogObserver

// ✅ Attach LogObserver globally
$logObserver = new LogObserver($conn);
Ticket::attach($logObserver);
Event::attach($logObserver);
User::attach($logObserver);

// Instantiate controller
$controller = new TicketController($conn);

// Determine action and event ID
$action  = $_GET['action'] ?? 'checkout'; // ✅ default to checkout instead of list
$eventId = isset($_GET['event_id']) ? (int) $_GET['event_id'] : null;

// Helper: redirect with error
function redirectWithError($message) {
    $_SESSION['error'] = $message;
    header("Location: events.php?action=list");
    exit;
}

try {
    switch ($action) {
        /* ---------------- CHECKOUT ---------------- */
        case 'checkout':
            if ($eventId) {
                $controller->checkout($eventId);
            } else {
                redirectWithError("Event ID missing.");
            }
            break;

        /* ---------------- CONFIRMATION ---------------- */
        case 'confirmation':
            if ($eventId) {
                $controller->confirmation($eventId);
            } else {
                redirectWithError("Event ID missing.");
            }
            break;

        /* ---------------- JSON ENDPOINTS (optional) ---------------- */
        case 'ticketsJson':
            header('Content-Type: application/json');
            try {
                $userId = $_SESSION['user_id'] ?? null;
                if ($userId) {
                    echo json_encode(Ticket::getByUserId($conn, $userId));
                } else {
                    echo json_encode(['error' => 'Login required']);
                }
            } catch (Exception $e) {
                echo json_encode(['error' => $e->getMessage()]);
            }
            exit;

        /* ---------------- DEFAULT ---------------- */
        default:
            redirectWithError("Invalid ticket action requested.");
            break;
    }
} catch (Exception $e) {
    redirectWithError($e->getMessage());
}