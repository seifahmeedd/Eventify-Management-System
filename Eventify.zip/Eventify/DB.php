<?php
// Database connection settings
$servername = "localhost";
$username   = "root";
$password   = "";
$dbname     = "eventify";

// Enable strict error reporting for mysqli
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

try {
    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

} catch (Exception $e) {
    // If connection fails, log error and stop execution
    error_log("Database connection failed: " . $e->getMessage());
    die("Database connection failed. Please check your settings.");
}