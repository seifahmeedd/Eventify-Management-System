<?php
ob_start();
session_start();
require_once 'db.php';

// Require controllers
require_once 'controllers/LogController.php';
require_once 'controllers/AdminController.php';
require_once 'controllers/TicketController.php';

// Require models
require_once 'models/Event.php';
require_once 'models/Ticket.php';
require_once 'models/User.php';
require_once 'models/Log.php'; // ✅ Needed for LogObserver

// ✅ Attach LogObserver globally
$logObserver = new LogObserver($conn);
Event::attach($logObserver);
Ticket::attach($logObserver);
User::attach($logObserver);

// ✅ Access control
if (!isset($_SESSION['user_id'])) {
    header('Location: users.php?action=login');
    exit;
}
if (($_SESSION['user_role'] ?? 'user') !== 'admin') {
    header('Location: users.php?action=dashboard');
    exit;
}

// Instantiate controllers
$logController    = new LogController($conn);
$adminController  = new AdminController($conn);
$ticketController = new TicketController($conn);

// Get action + id from query string
$action = $_GET['action'] ?? 'dashboard';
$id     = isset($_GET['id']) ? (int) $_GET['id'] : null;

// Helper: ensure ID exists for actions that need it
function requireId($id) {
    if (!$id) {
    echo "<div class='alert error'>An error occurred.</div>";
        exit;
    }
}

// Helper: redirect with error message
function redirectWithError($message) {
    $_SESSION['error'] = $message;
    header('Location: admin.php?action=dashboard');
    exit;
}

// Route actions
try {
    switch ($action) {
        case 'dashboard':
            $adminController->dashboard();
            break;

        /* ---------------- USERS CRUD ---------------- */
        case 'users':
            $adminController->users();
            break;
        case 'addUser':
            $adminController->addUser();
            break;
        case 'editUser':
            requireId($id);
            $adminController->editUser($id);
            break;
        case 'deleteUser':
            requireId($id);
            $adminController->deleteUser($id);
            break;

        /* ---------------- EVENTS CRUD ---------------- */
        case 'events':
            $adminController->events();
            break;
        case 'addEvent':
            $adminController->addEvent();
            break;
        case 'editEvent':
            requireId($id);
            $adminController->editEvent($id);
            break;
        case 'deleteEvent':
            requireId($id);
            $adminController->deleteEvent($id);
            break;

        /* ---------------- LOGS + TICKETS ---------------- */
        case 'logs':
            $logController->index();
            break;
        case 'ticket':
            requireId($id);
            $ticketController->view($id);
            break;

        /* ---------------- JSON ENDPOINT ---------------- */
        case 'eventsJson':
            header('Content-Type: application/json');
            echo json_encode(Event::all($conn));
            exit;

        default:
            $adminController->dashboard();
            break;
    }
} catch (Exception $e) {
    redirectWithError($e->getMessage());
}