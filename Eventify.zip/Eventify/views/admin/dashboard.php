<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Admin Dashboard</title>
  <link rel="stylesheet" href="public/style.css">
  <script src="public/app.js"></script>
</head>
<body>
  <div class="app">
    <?php include __DIR__ . '/../partials/header.php'; ?>


    <!-- Main Content -->
    <main class="container">
      <section class="dash">
        <!-- Sidebar Navigation -->
        <aside class="sidenav card">
          <a href="admin.php?action=dashboard" class="btn active">Overview</a>
          <a href="admin.php?action=users" class="btn">Users</a>
          <a href="admin.php?action=events" class="btn">Events</a>
          <a href="admin.php?action=logs" class="btn">Logs</a>
        </aside>

        <!-- Dashboard Body -->
        <div>
          <!-- Page Title -->
          <div class="card">
            <h2>Admin Overview</h2>
          </div>

          <!-- Alerts -->
          <?php if (isset($_GET['msg'])): ?>
            <?php 
              $msg = $_GET['msg'];
              $class = in_array($msg, ['error','notfound']) ? 'error' : 'success';
            ?>
            <div class="alert <?= $class ?>">
              <?php if ($msg === 'added'): ?>
                Event added successfully.
              <?php elseif ($msg === 'updated'): ?>
                Event updated successfully.
              <?php elseif ($msg === 'deleted'): ?>
                Event deleted successfully.
              <?php elseif ($msg === 'notfound'): ?>
                Event not found.
              <?php elseif ($msg === 'error'): ?>
                An error occurred.
              <?php endif; ?>
            </div>
          <?php endif; ?>

          <!-- Summary Cards -->
          <div class="summary-cards grid">
            <div class="card center">
              <h3><?= htmlspecialchars($totalUsers) ?></h3>
              <p class="muted">Total Users</p>
            </div>
            <div class="card center">
              <h3><?= htmlspecialchars($totalTickets) ?></h3>
              <p class="muted">Tickets Sold</p>
            </div>
            <div class="card center">
              <h3><?= htmlspecialchars($activeEvents) ?></h3>
              <p class="muted">Active Events</p>
            </div>
          </div>

          <div class="card center">
            <!-- ✅ Use preformatted revenue -->
            <h3><?= htmlspecialchars($totalRevenueFormatted ?? number_format($totalRevenue, 2) . " EGP") ?></h3>
            <p class="muted">Total Revenue</p>
          </div>

          <!-- Events Table -->
          <div class="card">
            <h3>Events</h3>
            <table>
              <thead>
                <tr>
                  <th scope="col">ID</th>
                  <th scope="col">Title</th>
                  <th scope="col">Category</th>
                  <th scope="col">Date</th>
                  <th scope="col">Status</th>
                </tr>
              </thead>
              <tbody>
                <?php if (empty($events)): ?>
                  <tr><td colspan="5" class="center muted">No events found.</td></tr>
                <?php else: ?>
                  <?php foreach ($events as $event): ?>
                    <tr>
                      <td>#<?= htmlspecialchars($event['id']) ?></td>
                      <td><?= htmlspecialchars($event['title']) ?></td>
                      <td><?= htmlspecialchars($event['category']) ?></td>
                      <td><?= htmlspecialchars($event['date']) ?></td>
                      <td>
                        <span class="tag 
                          <?= $event['status'] === 'active' ? 'success' : 
                             ($event['status'] === 'cancelled' ? 'danger' : 
                             ($event['status'] === 'sold_out' ? 'warning' : '')) ?>">
                          <?= ucfirst(htmlspecialchars($event['status'])) ?>
                        </span>
                      </td>
                    </tr>
                  <?php endforeach; ?>
                <?php endif; ?>
              </tbody>
            </table>
          </div>
        </div>
      </section>
    </main>

    <?php include __DIR__ . '/../partials/footer.php'; ?>

  </div>
</body>
</html>