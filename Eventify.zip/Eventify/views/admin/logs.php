<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Admin Logs</title>
  <link rel="stylesheet" href="public/style.css">
  <script src="public/app.js"></script>
</head>
<body>
  <div class="app">
    <?php include __DIR__ . '/../partials/header.php'; ?>

    <!-- Main Content -->
    <main class="container">
      <section class="dash">
        <!-- Sidebar Navigation -->
        <aside class="sidenav card">
          <a href="admin.php?action=dashboard" class="btn">Overview</a>
          <a href="admin.php?action=users" class="btn">Users</a>
          <a href="admin.php?action=events" class="btn">Events</a>
          <a href="admin.php?action=logs" class="btn active">Logs</a>
        </aside>

        <!-- Logs Table -->
        <div>
          <div class="card">
            <h2>System Logs</h2>
            <p class="muted">Track admin actions and system events</p>
          </div>

          <!-- Alerts -->
          <?php if (isset($_GET['msg'])): ?>
              <div class="alert error">
              <?php if ($_GET['msg'] === 'notfound'): ?>
                Log not found.
              <?php elseif ($_GET['msg'] === 'error'): ?>
                An error occurred while processing logs.
              <?php endif; ?>
            </div>
          <?php endif; ?>

          <div class="card">
            <table>
              <thead>
                <tr>
                  <th scope="col">ID</th>
                  <th scope="col">User</th>
                  <th scope="col">Action</th>
                  <th scope="col">Status</th>
                  <th scope="col">Timestamp</th>
                </tr>
              </thead>
              <tbody>
                <?php if (empty($logs)): ?>
                  <tr><td colspan="5" class="center muted">No logs found.</td></tr>
                <?php else: ?>
                  <?php foreach ($logs as $log): ?>
                    <tr>
                      <td>#<?= htmlspecialchars($log['id']) ?></td>
                      <td><?= htmlspecialchars($log['user_name'] ?? 'System') ?></td>
                      <td><?= htmlspecialchars($log['action']) ?></td>
                      <td>
                        <span class="status 
                          <?= $log['status'] === 'success' ? 'active' : 
                              ($log['status'] === 'warning' ? 'warning' : 'danger') ?>">
                          <?= ucfirst(htmlspecialchars($log['status'])) ?>
                        </span>
                      </td>
                      <td><?= htmlspecialchars($log['timestamp']) ?></td>
                    </tr>
                  <?php endforeach; ?>
                <?php endif; ?>
              </tbody>
            </table>
          </div>
        </div>
      </section>
    </main>

    <?php include __DIR__ . '/../partials/footer.php'; ?>

  </div>
</body>
</html>