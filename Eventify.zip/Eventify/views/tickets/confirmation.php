<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Ticket Confirmation</title>
  <link rel="stylesheet" href="public/style.css">
  <script src="public/app.js"></script>
</head>
<body>
  <div class="app">
    <?php include __DIR__ . '/../partials/header.php'; ?>

    <!-- Main Content -->
    <main class="container">
      <section class="card">
        <h2>Ticket Confirmation</h2>

        <?php if (!empty($error)): ?>
          <div class="alert error"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        <?php if (!empty($success)): ?>
          <div class="alert success"><?= htmlspecialchars($success) ?></div>
        <?php endif; ?>

        <?php if (!empty($event) && !empty($tickets)): ?>
          <p class="muted">Thank you for your purchase! Your tickets are confirmed.</p>

          <!-- Event Summary -->
          <div class="card">
            <h3><?= htmlspecialchars($event['title']) ?></h3>
            <p><strong>Date:</strong> <?= htmlspecialchars($event['date']) ?></p>
            <p><strong>Venue:</strong> <?= htmlspecialchars($event['venue']) ?></p>
            <p><strong>Total Spent:</strong>
<?= number_format((float)($totalSpent ?? array_sum(array_column($tickets, 'price'))), 2) ?> EGP
</p>
            </p>
            <p><strong>Status:</strong>
              <span class="tag success">Confirmed</span>
            </p>
          </div>

          <!-- Tickets -->
          <div class="card">
            <h3>Your Tickets</h3>
            <table>
              <thead>
                <tr>
                  <th scope="col">Seat</th>
                  <th scope="col">Code</th>
                  <th scope="col">Price</th>
                  <th scope="col">QR</th>
                </tr>
              </thead>
              <tbody>
                <?php foreach ($tickets as $ticket): ?>
                  <tr>
                    <td><?= $ticket['seat'] ? htmlspecialchars($ticket['seat']) : 'General Admission' ?></td>
                    <td>
                      <?= htmlspecialchars($ticket['code']) ?>
                    </td>
<td><?= number_format((float)$ticket['price'], 2) ?> EGP</td>
                    <td>
                      <img src="https://api.qrserver.com/v1/create-qr-code/?data=<?= urlencode($ticket['code']) ?>&size=100x100"
                           alt="QR Code for <?= htmlspecialchars($ticket['code']) ?>">
                    </td>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>

          <!-- Dashboard Link -->
          <?php if (isset($_SESSION['user_id'])): ?>
            <a href="users.php?action=dashboard" class="btn primary">Go to Dashboard</a>
          <?php else: ?>
            <a href="users.php?action=login" class="btn primary">Login to view Dashboard</a>
          <?php endif; ?>
        <?php else: ?>
          <div class="alert error">No tickets found for this event.</div>
        <?php endif; ?>
      </section>
    </main>

    <?php include __DIR__ . '/../partials/footer.php'; ?>

  </div>
</body>
</html>