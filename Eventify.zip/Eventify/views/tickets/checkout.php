<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Checkout</title>
  <link rel="stylesheet" href="public/style.css">
  <script src="public/app.js"></script>
</head>
<body>
  <div class="app">
    <?php include __DIR__ . '/../partials/header.php'; ?>

    <!-- Main Content -->
    <main class="container">
      <section class="hero">
        <!-- Left: Order Summary -->
        <div class="left card">
          <h2>Order Summary</h2>

          <?php if (!empty($error)): ?>
            <div class="alert error"><?= htmlspecialchars($error) ?></div>
          <?php endif; ?>
          <?php if (!empty($success)): ?>
            <div class="alert success"><?= htmlspecialchars($success) ?></div>
          <?php endif; ?>

          <?php if (!empty($event)): ?>
            <?php $quantity = isset($_POST['quantity']) ? (int)$_POST['quantity'] : 1; ?>
            <div class="row">
              <div>
                <h4><?= htmlspecialchars($event['title']) ?></h4>
                <p class="muted"><?= $quantity ?> × Ticket</p>
              </div>
              <div>
              <?= number_format($event['price'] * $quantity, 2) ?> EGP
              </div>
            </div>
            <hr>
            <div class="row">
              <strong>Total:</strong>
              <strong><?= number_format($event['price'] * $quantity, 2) ?> EGP</strong>
            </div>
          <?php else: ?>
            <p class="muted">No event selected.</p>
          <?php endif; ?>
        </div>

        <!-- Right: Payment Form -->
        <div class="right card">
          <h2>Payment Details</h2>
          <?php if (!empty($event)): ?>
            <p class="muted">Event: <strong><?= htmlspecialchars($event['title']) ?></strong></p>
            <p class="muted">Date: <?= htmlspecialchars($event['date']) ?></p>
            <p class="muted">Venue: <?= htmlspecialchars($event['venue']) ?></p>
          <?php endif; ?>

          <form method="POST" action="tickets.php?action=checkout&event_id=<?= htmlspecialchars($event['id'] ?? '') ?>" class="form">
            <div class="form-group">
              <label for="cardName">Cardholder Name</label>
              <input id="cardName" type="text" name="cardName" required>
            </div>

            <div class="form-group">
              <label for="cardNumber">Card Number</label>
              <input id="cardNumber" type="text" name="cardNumber" maxlength="19"
                     pattern="\d{13,19}" inputmode="numeric"
                     placeholder="1234 5678 9012 3456" required>
            </div>

            <div>
                <label for="expiry">Expiry Date</label>
                <input id="expiry" type="month" name="expiry" required aria-label="Expiry date (MM/YY)">
              
                <label for="cvv">CVV</label>
                <input id="cvv" type="text" name="cvv" maxlength="3" pattern="\d{3}" aria-describedby="cvvHelp" required>
                <small id="cvvHelp" class="muted">3 digits on the back of card</small>
            </div>

            <div>
              <label for="quantity">Add More Tickets</label>
              <input id="quantity" type="number" name="quantity" min="1"
                     value="<?= $quantity ?>">
            </div>

            <button type="submit" class="btn primary">Confirm Payment</button>
          </form>
        </div>
      </section>
    </main>

    <?php include __DIR__ . '/../partials/footer.php'; ?>

  </div>
</body>
</html>