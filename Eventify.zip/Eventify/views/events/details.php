<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title><?= !empty($event) ? htmlspecialchars($event['title']) . ' - Event Details' : 'Event Not Found' ?></title>
  <link rel="stylesheet" href="public/style.css">
  <script src="public/app.js"></script>
</head>
<body>
  <div class="app">
    <?php include __DIR__ . '/../partials/header.php'; ?>

    <!-- Main Content -->
    <main class="container">
      <?php if (!empty($event)): ?>
        <section class="hero">
          <!-- Left: Event Info -->
          <div class="left">
            <h2><?= htmlspecialchars($event['title']) ?></h2>
            <p class="muted">
              • <?= htmlspecialchars($event['venue']) ?> <br>
              • <?= htmlspecialchars($event['date']) ?> at <?= htmlspecialchars($event['time']) ?>
            </p>
             <p>-<?= nl2br(htmlspecialchars($event['description'])) ?></p>
             <p class="muted">• Category: <?= htmlspecialchars($event['category']) ?></p>
             <p class="muted">• Capacity: <?= htmlspecialchars($event['capacity']) ?> <?= $event['has_seats'] ? 'seats' : 'spots' ?></p>
          </div>

          <!-- Right: Booking Info -->
          <div class="right card">
            <!-- ✅ Use preformatted price -->
            <h2><?= htmlspecialchars($event['price_formatted'] ?? number_format((float)$event['price'], 2) . " EGP") ?></h2>
            <?php if (isset($_SESSION['user_id'])): ?>
              <?php if ($event['status'] === 'active' && $event['capacity'] > 0): ?>
                <a href="tickets.php?action=checkout&event_id=<?= htmlspecialchars($event['id']) ?>" class="btn primary">Reserve Tickets</a>
              <?php elseif ($event['status'] === 'sold_out' || $event['capacity'] <= 0): ?>
                <span class="tag warning">Sold Out</span>
              <?php elseif ($event['status'] === 'cancelled'): ?>
                <span class="tag danger">Cancelled</span>
              <?php endif; ?>
            <?php else: ?>
              <a href="users.php?action=register" class="btn">Register to Reserve</a>
            <?php endif; ?>
          </div>
        </section>
      <?php else: ?>
        <section class="card center">
          <div class="alert error">Event Not Found</div>
          <p class="muted">Sorry, the event you are looking for does not exist.</p>
          <a href="events.php?action=list" class="btn primary">Back to Events</a>
        </section>
      <?php endif; ?>
    </main>

    <?php include __DIR__ . '/../partials/footer.php'; ?>

  </div>
</body>
</html>