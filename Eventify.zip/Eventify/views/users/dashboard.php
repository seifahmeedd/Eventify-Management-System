<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>User Dashboard</title>
  <link rel="stylesheet" href="public/style.css">
  <script src="public/app.js"></script>
</head>
<body>
  <div class="app">
    <?php include __DIR__ . '/../partials/header.php'; ?>

    <!-- Main Content -->
    <main class="container">
      <section class="dash">
        <!-- Sidebar Navigation -->
        <aside class="sidenav card">
          <a href="events.php?action=list" class="btn">Events</a>
        </aside>

        <!-- Dashboard Body -->
        <div>
          <!-- Feedback Messages -->
          <?php if (isset($error) && !empty($error)): ?>
            <div class="alert error"><?= htmlspecialchars($error) ?></div>
          <?php endif; ?>
          <?php if (isset($success) && !empty($success)): ?>
            <div class="alert success"><?= htmlspecialchars($success) ?></div>
          <?php endif; ?>

          <!-- Welcome Card -->
          <div class="card">
            <h1>Welcome, <?= htmlspecialchars($user['name'] ?? 'Guest') ?></h1>
            <p class="muted">Overview of your account activity.</p>
          </div>

          <!-- Summary Cards -->
          <div class="summary-cards grid">
            <div class="card center">
              <h3><?= htmlspecialchars($ticketCount ?? 0) ?></h3>
              <p class="muted">Tickets</p>
            </div>
            <div class="card center">
              <h3><?= htmlspecialchars($totalSpentFormatted ?? number_format((float)($totalSpent ?? 0), 2) . " EGP") ?></h3>
              <p class="muted">Total Spent</p>
            </div>
          </div>

          <!-- Recent Tickets -->
          <div class="card">
            <h3>Recent Tickets</h3>
            <table id="ticketsTable" aria-label="Recent Tickets">
              <thead>
                <tr>
                  <th scope="col">Event</th>
                  <th scope="col">Date</th>
                  <th scope="col">Seat</th>
                  <th scope="col">Code</th>
                  <th scope="col">Actions</th>
                </tr>
              </thead>
              <tbody>
                <?php if (empty($recentTickets)): ?>
                  <tr><td colspan="5" class="center muted">No tickets found.</td></tr>
                <?php else: ?>
                  <?php foreach ($recentTickets as $t): ?>
                    <tr>
                      <td><?= htmlspecialchars($t['event']) ?></td>
                      <td><?= htmlspecialchars($t['date']) ?></td>
                      <td><?= $t['seat'] ? htmlspecialchars($t['seat']) : 'General Admission' ?></td>
                      <td><?= htmlspecialchars($t['code']) ?></td>
                      <td>
                        <a href="tickets.php?action=confirmation&event_id=<?= (int)$t['event_id'] ?>"
                           class="btn small">View Confirmation</a>
                      </td>
                    </tr>
                  <?php endforeach; ?>
                <?php endif; ?>
              </tbody>
            </table>
          </div>
        </div>
      </section>
    </main>

    <?php include __DIR__ . '/../partials/footer.php'; ?>
  </div>
</body>
</html>