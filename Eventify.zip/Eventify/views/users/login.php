<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Login</title>
  <link rel="stylesheet" href="public/style.css" />
  <script src="public/app.js"></script>
</head>
<body>
  <div class="app">
    <?php include __DIR__ . '/../partials/header.php'; ?>
      
    <!-- Main Content -->
    <main class="container">
      <section class="card form-card">
        <h1>Login to Your Account</h1>

        <!-- Feedback Messages -->
        <?php if (isset($error) && !empty($error)): ?>
          <div class="alert error"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        <?php if (isset($success) && !empty($success)): ?>
          <div class="alert success"><?= htmlspecialchars($success) ?></div>
        <?php endif; ?>

        <!-- Login Form -->
        <form method="POST" action="users.php?action=login" id="loginForm" class="form">
          <div class="form-group">
            <label for="email">Email</label>
            <input id="email" type="email" name="email" required placeholder="you@example.com" aria-label="Email address" autocomplete="email">
          </div>

          <div class="form-group">
            <label for="password">Password</label>
            <input id="password" type="password" name="password" required placeholder="********" aria-label="Password" autocomplete="current-password">
          </div>

          <button type="submit" class="btn primary">Login</button>
        </form>

        <p class="muted">
          Don't have an account? <a href="users.php?action=register">Register here</a>
        </p>
      </section>
    </main>

    <?php include __DIR__ . '/../partials/footer.php'; ?>

  </div>
</body>
</html>