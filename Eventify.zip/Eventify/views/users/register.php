<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Register</title>
  <link rel="stylesheet" href="public/style.css" />
  <script src="public/app.js"></script>
</head>
<body>
  <div class="app">
    <?php include __DIR__ . '/../partials/header.php'; ?>

    <!-- Main Content -->
    <main class="container">
      <section class="card form-card">
        <h1>Create a New Account</h1>

        <!-- Feedback Messages -->
        <?php if (!empty($error)): ?>
          <div class="alert error"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        <?php if (!empty($success)): ?>
          <div class="alert success"><?= htmlspecialchars($success) ?></div>
        <?php endif; ?>

        <!-- Registration Form -->
        <form method="POST" action="users.php?action=register" id="registerForm" class="form">
          <div class="form-group">
            <label for="registerName">Name</label>
            <input id="registerName" type="text" name="name" required placeholder="Full Name"
                   value="<?= htmlspecialchars($_POST['name'] ?? '') ?>" aria-label="Full Name">
          </div>

          <div class="form-group">
            <label for="registerEmail">Email</label>
            <input id="registerEmail" type="email" name="email" required placeholder="you@example.com"
                   value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" aria-label="Email address">
          </div>

          <div class="form-group">
            <label for="registerPassword">Password</label>
            <input id="registerPassword" type="password" name="password" required placeholder="********" minlength="8" aria-label="Password">
            <small class="muted">Minimum 8 characters</small>
          </div>

          <div class="form-group">
            <label for="registerConfirmPassword">Confirm Password</label>
            <input id="registerConfirmPassword" type="password" name="confirm_password" required placeholder="********" aria-label="Confirm password">
          </div>

          <button type="submit" class="btn primary">Register</button>
        </form>

        <p class="muted">
          Already have an account? <a href="users.php?action=login">Login here</a>
        </p>
      </section>
    </main>

    <?php include __DIR__ . '/../partials/footer.php'; ?>

  </div>
</body>
</html>