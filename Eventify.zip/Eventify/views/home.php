<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Home Page</title>
  <link rel="stylesheet" href="public/style.css">
  <script src="public/app.js"></script>
</head>
<body>
  <div class="app">
    <?php include __DIR__ . '/partials/header.php'; ?>

    <!-- Main Content -->
    <main class="container">
      <section class="card">
        <h1>Upcoming Events</h1>
        <div class="grid">
          <?php if (empty($events)): ?>
            <div class="alert error center">No events available.</div>
          <?php else: ?>
            <?php foreach ($events as $event): ?>
              <div class="card event-card">
                <h3><?= htmlspecialchars($event['title']) ?></h3>
                <p class="muted">
                 • Category: <?= htmlspecialchars($event['category']) ?> <br>
                 • Date: <?= htmlspecialchars($event['date'] ?? 'TBA') ?>
                </p>
                <div class="row">
                  <!-- ✅ Use preformatted price -->
                  <span><?= htmlspecialchars($event['price_formatted'] ?? number_format((float)$event['price'], 2) . " EGP") ?></span>
                  <a href="events.php?action=details&id=<?= htmlspecialchars($event['id']) ?>" class="btn primary">Details</a>
                </div>
              </div>
            <?php endforeach; ?>
          <?php endif; ?>
        </div>
      </section>
    </main>

<?php include __DIR__ . '/partials/footer.php'; ?>

</div>
</body>
</html>