<?php
$currentFile   = basename($_SERVER['PHP_SELF']);
$currentAction = $_GET['action'] ?? null;

// Default logo link
$logoHref = "events.php?action=home";

if (isset($_SESSION['user_id'])) {
    if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin') {
        $logoHref = "admin.php?action=dashboard";
    } else {
        $logoHref = "users.php?action=dashboard";
    }

    // Special case: event details page
    if ($currentFile === 'events.php' && $currentAction === 'details') {
        $logoHref = "users.php?action=dashboard";
    }
}
?>

<header id="header">
  <!-- Logo -->
  <a href="<?= $logoHref ?>" class="eb-logo">
    <img src="public/logo/logo.png" alt="Eventify logo" class="logo-img">
  </a>

  <!-- Search (only on home or events page) -->
  <?php if ($currentFile === 'home.php' || $currentFile === 'events.php'): ?>
    <div class="header-search">
      <input type="search" id="searchInput" placeholder="Search events..." aria-label="Search events">
    </div>
  <?php endif; ?>

  <!-- Navigation -->
  <nav>
    <?php if (!empty($menuEvents)): ?>
      <?php foreach ($menuEvents as $event): ?>
        <a href="events.php?action=details&id=<?= htmlspecialchars($event['id']) ?>">
          <?= htmlspecialchars($event['title']) ?>
        </a>
      <?php endforeach; ?>
    <?php endif; ?>

    <?php if (isset($_SESSION['user_id'])): ?>
      <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
        <a href="admin.php?action=dashboard" class="btn">Admin Dashboard</a>
        <a href="users.php?action=logout" class="btn danger">Logout</a>
      <?php else: ?>
        <a href="users.php?action=dashboard" class="btn">Dashboard</a>
        <a href="users.php?action=logout" class="btn danger">Logout</a>
      <?php endif; ?>
    <?php else: ?>
      <a href="users.php?action=login" class="btn">Login</a>
      <a href="users.php?action=register" class="btn primary">Register</a>
    <?php endif; ?>
  </nav>
</header>