<div>
  <footer>
    <div>
      <p>Find it. Book it. Live it — with Eventify.</p>
      <p>&copy; <?= date('Y') ?> Eventify. All rights reserved.</p>
    </div>
  </footer>
</div>