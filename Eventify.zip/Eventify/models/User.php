<?php
require_once __DIR__ . '/Log.php'; // to access Observer + LogObserver

class User {
    /* ---------------- OBSERVER SUPPORT ---------------- */
    private static $observers = [];

    public static function attach(Observer $observer) {
        self::$observers[] = $observer;
    }

    private static function notify($action, $userId = null, $email = null) {
        foreach (self::$observers as $observer) {
            $subject = (object)[
                'id'     => $userId,
                'entity' => 'User',
                'label'  => $email ?? "User #$userId",
                'actor'  => $_SESSION['user_name'] ?? 'System'
            ];
            $observer->update($subject, $action);
        }
    }

    /* ---------------- FACTORY METHOD ---------------- */
    public static function factoryCreate($conn, $name, $email, $password, $role = 'user', $status = 'active') {
        // ✅ Email validation
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            throw new Exception("Invalid email format.");
        }
        if (!self::isValidEmailDomain($email)) {
            throw new Exception("Email must be Gmail, Hotmail, Outlook, or Yahoo.");
        }

        // ✅ Password validation
        if (!self::isStrongPassword($password)) {
            throw new Exception("Password must be at least 8 characters long, contain a capital letter, and a number.");
        }

        // ✅ Duplicate check
        if (self::findByEmail($conn, $email)) {
            throw new Exception("This email is already registered.");
        }

        // ✅ Role & status validation
        if (!in_array(strtolower($role), ['admin','user'])) {
            throw new Exception("Invalid role value.");
        }
        if (!in_array(strtolower($status), ['active','banned'])) {
            throw new Exception("Invalid status value.");
        }

        // ✅ Insert user
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        $sql = "INSERT INTO users (name, email, password, role, status, created_at) 
                VALUES (?, ?, ?, ?, ?, NOW())";
        $stmt = $conn->prepare($sql);
        if (!$stmt) {
            throw new Exception("User::factoryCreate prepare failed: " . $conn->error);
        }
        $stmt->bind_param("sssss", $name, $email, $hashedPassword, strtolower($role), strtolower($status));
        if ($stmt->execute()) {
            $userId = $conn->insert_id;
            self::notify("Created User", $userId, $email);
            return $userId;
        }
        throw new Exception("User::factoryCreate execute failed: " . $stmt->error);
    }

    /* ---------------- AUTH ---------------- */
    public static function register($conn, $username, $email, $password) {
        return self::factoryCreate($conn, $username, $email, $password, 'user', 'active');
    }

    public static function login($conn, $email, $password) {
    $sql = "SELECT * FROM users WHERE email = ?";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        throw new Exception("User::login prepare failed: " . $conn->error);
    }
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result ? $result->fetch_assoc() : null;

    if ($user && password_verify($password, $user['password'])) {
        // ✅ Return user even if banned
        return $user;
    }
    return null;
}

    public static function count($conn) {
        $sql = "SELECT COUNT(*) AS total_users FROM users";
        $result = $conn->query($sql);
        return $result ? (int)$result->fetch_assoc()['total_users'] : 0;
    }

    /* ---------------- ADMIN FUNCTIONS ---------------- */
    public static function create($conn, $name, $email, $password, $role, $status) {
        return self::factoryCreate($conn, $name, $email, $password, $role, $status);
    }

    public static function update($conn, $id, $name, $email, $role, $status) {
        $id = (int)$id;
        if (!in_array(strtolower($role), ['admin','user'])) {
            throw new Exception("Invalid role value.");
        }
        if (!in_array(strtolower($status), ['active','banned'])) {
            throw new Exception("Invalid status value.");
        }

        $sql = "UPDATE users SET name = ?, email = ?, role = ?, status = ? WHERE id = ?";
        $stmt = $conn->prepare($sql);
        if (!$stmt) {
            throw new Exception("User::update prepare failed: " . $conn->error);
        }
        $stmt->bind_param("ssssi", $name, $email, strtolower($role), strtolower($status), $id);
        if ($stmt->execute()) {
            self::notify("Updated User", $id, $email);
            return true;
        }
        throw new Exception("User::update execute failed: " . $stmt->error);
    }

    public static function delete($conn, $id) {
        $id = (int)$id;
        $user = self::getById($conn, $id);
        $email = $user['email'] ?? null;

        $sql = "DELETE FROM users WHERE id = ?";
        $stmt = $conn->prepare($sql);
        if (!$stmt) {
            throw new Exception("User::delete prepare failed: " . $conn->error);
        }
        $stmt->bind_param("i", $id);
        if ($stmt->execute()) {
            self::notify("Deleted User", $id, $email);
            return true;
        }
        throw new Exception("User::delete execute failed: " . $stmt->error);
    }

    public static function getById($conn, $id) {
        $id = (int)$id;
        $sql = "SELECT * FROM users WHERE id = ?";
        $stmt = $conn->prepare($sql);
        if (!$stmt) {
            throw new Exception("User::getById prepare failed: " . $conn->error);
        }
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result ? $result->fetch_assoc() : null;
    }

    public static function all($conn) {
        $sql = "SELECT * FROM users ORDER BY created_at ASC";
        $result = $conn->query($sql);
        return $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
    }

    /* ---------------- OPTIONAL HELPERS ---------------- */
    public static function findByEmail($conn, $email) {
        $sql = "SELECT * FROM users WHERE email = ?";
        $stmt = $conn->prepare($sql);
        if (!$stmt) {
            throw new Exception("User::findByEmail prepare failed: " . $conn->error);
        }
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result ? $result->fetch_assoc() : null;
    }

        // ✅ Password strength check
    public static function isStrongPassword($password) {
        $lengthOk   = strlen($password) >= 8;          // at least 8 characters
        $hasUpper   = preg_match('/[A-Z]/', $password); // contains uppercase letter
        $hasNumber  = preg_match('/[0-9]/', $password); // contains number

        return $lengthOk && $hasUpper && $hasNumber;
    }

    // ✅ Email domain check
    public static function isValidEmailDomain($email) {
        $allowedDomains = ['gmail.com', 'hotmail.com', 'outlook.com', 'yahoo.com'];
        $domain = substr(strrchr($email, "@"), 1);
        return in_array(strtolower($domain), $allowedDomains);
    }
}