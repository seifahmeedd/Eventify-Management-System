<?php
require_once __DIR__ . '/Log.php'; // to access Observer + LogObserver

class Event {
    /* ---------------- OBSERVER SUPPORT ---------------- */
    private static $observers = [];

    public static function attach(Observer $observer) {
        self::$observers[] = $observer;
    }

    private static function notify($action, $eventId = null, $title = null) {
        foreach (self::$observers as $observer) {
            $subject = (object)[
                'id'     => $eventId,
                'entity' => 'Event',
                'label'  => $title ?? "Event #$eventId",
                'actor'  => $_SESSION['user_name'] ?? 'System'
            ];
            $observer->update($subject, $action);
        }
    }

    /* ---------------- HELPER: FORMAT CURRENCY ---------------- */
    public static function formatEGP($amount) {
        return number_format((float)$amount, 2) . " EGP";
    }

    /* ---------------- PUBLIC FUNCTIONS ---------------- */
    public static function all($conn) {
        $sql = "SELECT id, title, description, venue, date, time, category, capacity, price, status, has_seats 
                FROM events 
                ORDER BY id ASC";
        $result = $conn->query($sql);
        $events = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];

        foreach ($events as $i => $ev) {
            $events[$i]['price_formatted'] = self::formatEGP($ev['price']);
        }
        return $events;
    }

    public static function getById($conn, $id) {
        $sql = "SELECT id, title, description, venue, date, time, category, capacity, price, status, has_seats 
                FROM events WHERE id = ?";
        $stmt = $conn->prepare($sql);
        if (!$stmt) {
            throw new Exception("Event::getById prepare failed: " . $conn->error);
        }
        $id = (int)$id;
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        $event = $result ? $result->fetch_assoc() : null;

        if ($event) {
            $event['price_formatted'] = self::formatEGP($event['price']);
        }
        return $event;
    }

    /* ---------------- FACTORY METHOD ---------------- */
    public static function factoryCreate($conn, $title, $description, $venue, $date, $time, $category, $capacity, $price, $status = 'active', $hasSeats = 0) {
        // ✅ Validation
        if (empty($title) || empty($venue) || empty($date) || empty($time)) {
            throw new Exception("Event must have a title, venue, date, and time.");
        }
        if (!is_numeric($capacity) || (int)$capacity < 0) {
            throw new Exception("Capacity must be a non-negative integer.");
        }
        if (!is_numeric($price) || (float)$price < 0) {
            throw new Exception("Price must be a non-negative number.");
        }
        if (!strtotime($date)) {
            throw new Exception("Invalid date format.");
        }
        if (!preg_match('/^\d{2}:\d{2}$/', $time)) {
            throw new Exception("Invalid time format (HH:MM expected).");
        }
        if (!in_array($status, ['active','banned'])) {
            throw new Exception("Invalid status value.");
        }

        $sql = "INSERT INTO events (title, description, venue, date, time, category, capacity, price, status, has_seats)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        if (!$stmt) {
            throw new Exception("Event::factoryCreate prepare failed: " . $conn->error);
        }
        $stmt->bind_param("ssssssidsi", $title, $description, $venue, $date, $time, $category, $capacity, $price, $status, $hasSeats);
        if ($stmt->execute()) {
            $eventId = $conn->insert_id;
            self::notify("Created Event", $eventId, $title);
            return $eventId;
        }
        throw new Exception("Event::factoryCreate execute failed: " . $stmt->error);
    }

    /* ---------------- ADMIN FUNCTIONS ---------------- */
    public static function create($conn, $title, $description, $venue, $date, $time, $category, $capacity, $price, $status, $hasSeats) {
        return self::factoryCreate($conn, $title, $description, $venue, $date, $time, $category, $capacity, $price, $status, $hasSeats);
    }

    public static function update($conn, $id, $title, $description, $venue, $date, $time, $category, $capacity, $price, $status, $hasSeats) {
        $sql = "UPDATE events 
                SET title = ?, description = ?, venue = ?, date = ?, time = ?, category = ?, capacity = ?, price = ?, status = ?, has_seats = ?
                WHERE id = ?";
        $stmt = $conn->prepare($sql);
        if (!$stmt) {
            throw new Exception("Event::update prepare failed: " . $conn->error);
        }
        $id = (int)$id;
        $stmt->bind_param("ssssssidsii", $title, $description, $venue, $date, $time, $category, $capacity, $price, $status, $hasSeats, $id);
        if ($stmt->execute()) {
            self::notify("Updated Event", $id, $title);
            return true;
        }
        throw new Exception("Event::update execute failed: " . $stmt->error);
    }

    public static function delete($conn, $id) {
        $event = self::getById($conn, $id);
        $title = $event['title'] ?? null;

        $sql = "DELETE FROM events WHERE id = ?";
        $stmt = $conn->prepare($sql);
        if (!$stmt) {
            throw new Exception("Event::delete prepare failed: " . $conn->error);
        }
        $id = (int)$id;
        $stmt->bind_param("i", $id);
        if ($stmt->execute()) {
            self::notify("Deleted Event", $id, $title);
            return true;
        }
        throw new Exception("Event::delete execute failed: " . $stmt->error);
    }

    /* ---------------- EXTRA UTILITIES ---------------- */
    public static function countActive($conn) {
        $sql = "SELECT COUNT(*) AS cnt FROM events WHERE status = 'active'";
        $result = $conn->query($sql);
        return $result ? (int)$result->fetch_assoc()['cnt'] : 0;
    }

    public static function getActiveEvents($conn) {
        $sql = "SELECT id, title, description, venue, date, time, category, capacity, price, status, has_seats 
                FROM events 
                WHERE status = 'active' 
                ORDER BY id ASC";
        $result = $conn->query($sql);
        $events = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];

        foreach ($events as $i => $ev) {
            $events[$i]['price_formatted'] = self::formatEGP($ev['price']);
        }
        return $events;
    }
}