<?php
require_once __DIR__ . '/Log.php'; // to access Observer + LogObserver

class Ticket {
    /* ---------------- OBSERVER SUPPORT ---------------- */
    private static $observers = [];

    public static function attach(Observer $observer) {
        self::$observers[] = $observer;
    }

    private static function notify($action, $ticketId = null, $eventTitle = null, $userName = null) {
        foreach (self::$observers as $observer) {
            $subject = (object)[
                'id'     => $ticketId,
                'entity' => 'Ticket',
                'label'  => $eventTitle ?? "Ticket #$ticketId",
                'actor'  => $userName ?? ($_SESSION['user_name'] ?? 'System')
            ];
            $observer->update($subject, $action);
        }
    }

    /* ---------------- FACTORY METHOD ---------------- */
    public static function factoryCreate($conn, $userId, $eventId, $seat, $code, $price, $eventTitle, $userName) {
        $sql = "INSERT INTO tickets (user_id, event_id, seat, code, price, time) 
                VALUES (?, ?, ?, ?, ?, NOW())";
        $stmt = $conn->prepare($sql);
        if (!$stmt) {
            throw new Exception("Ticket::factoryCreate prepare failed: " . $conn->error);
        }
        $stmt->bind_param("iissd", $userId, $eventId, $seat, $code, $price);
        if ($stmt->execute()) {
            $ticketId = $conn->insert_id;
            self::notify("Purchased Ticket", $ticketId, $eventTitle, $userName);
            return $ticketId;
        }
        throw new Exception("Ticket::factoryCreate execute failed: " . $stmt->error);
    }

    /* ---------------- HELPER: FORMAT CURRENCY ---------------- */
    public static function formatEGP($amount) {
        return number_format((float)$amount, 2) . " EGP";
    }

    /* ---------------- READ ---------------- */
    public static function getById($conn, $id) {
        $id = (int)$id;
        $sql = "SELECT * FROM tickets WHERE id = ?";
        $stmt = $conn->prepare($sql);
        if (!$stmt) throw new Exception("Ticket::getById prepare failed: " . $conn->error);
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        $ticket = $result ? $result->fetch_assoc() : null;

        if ($ticket) {
            $ticket['price_formatted'] = self::formatEGP($ticket['price']);
        }
        return $ticket;
    }

    public static function getByUserId($conn, $userId) {
        $userId = (int)$userId;
        $sql = "SELECT t.*, e.title, e.date, e.venue 
                FROM tickets t
                JOIN events e ON t.event_id = e.id
                WHERE t.user_id = ?
                ORDER BY e.date ASC";
        $stmt = $conn->prepare($sql);
        if (!$stmt) throw new Exception("Ticket::getByUserId prepare failed: " . $conn->error);
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $result = $stmt->get_result();
        $tickets = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];

        foreach ($tickets as &$ticket) {
            $ticket['price_formatted'] = self::formatEGP($ticket['price']);
        }
        return $tickets;
    }

    /* ---------------- PURCHASE ---------------- */
    public static function purchase($conn, $eventId, $userId, $quantity) {
        $eventId  = (int)$eventId;
        $userId   = (int)$userId;
        $quantity = (int)$quantity;

        if ($quantity <= 0) {
            throw new Exception("Quantity must be at least 1.");
        }

        // Fetch event details
        $sqlEvent = "SELECT title, price, has_seats, capacity, status FROM events WHERE id = ?";
        $stmtEvent = $conn->prepare($sqlEvent);
        if (!$stmtEvent) throw new Exception("Ticket::purchase event prepare failed: " . $conn->error);
        $stmtEvent->bind_param("i", $eventId);
        $stmtEvent->execute();
        $event = $stmtEvent->get_result()->fetch_assoc();

        if (!$event) throw new Exception("Event not found.");
        if ($event['status'] !== 'active') throw new Exception("Event is not active.");

        $price      = $event['price']; 
        $hasSeats   = (bool)$event['has_seats'];
        $capacity   = (int)$event['capacity'];
        $eventTitle = $event['title'] ?? "Event #$eventId";

        // ✅ Check capacity
        if ($capacity < $quantity) {
            throw new Exception("Not enough capacity for event $eventId");
        }

        // Find existing tickets count for seat offset
        $sqlCount = "SELECT COUNT(*) AS cnt FROM tickets WHERE event_id = ?";
        $stmtCount = $conn->prepare($sqlCount);
        $stmtCount->bind_param("i", $eventId);
        $stmtCount->execute();
        $existing = $stmtCount->get_result()->fetch_assoc()['cnt'] ?? 0;

        // Fetch user name/email for logging
        $user = User::getById($conn, $userId);
        $userName = $user['name'] ?? "User #$userId";

        $ticketIds = [];
        for ($i = 1; $i <= $quantity; $i++) {
            $seat = $hasSeats ? "S" . ($existing + $i) : null;
            // ✅ Stronger unique code
            $code = "TKT" . bin2hex(random_bytes(5));

            $ticketId = self::factoryCreate($conn, $userId, $eventId, $seat, $code, $price, $eventTitle, $userName);
            $ticketIds[] = $ticketId;
        }

        // ✅ Decrease capacity and auto-mark sold_out
        $newCapacity = $capacity - $quantity;
        $sqlUpdate = "UPDATE events SET capacity = ?, status = CASE WHEN ? = 0 THEN 'sold_out' ELSE status END WHERE id = ?";
        $stmtUpdate = $conn->prepare($sqlUpdate);
        $stmtUpdate->bind_param("iii", $newCapacity, $newCapacity, $eventId);
        $stmtUpdate->execute();

        return $ticketIds;
    }

    /* ---------------- UTILITIES ---------------- */
    public static function countByUser($conn, $userId) {
        $sql = "SELECT COUNT(*) AS cnt FROM tickets WHERE user_id = ?";
        $stmt = $conn->prepare($sql);
        if (!$stmt) throw new Exception("Ticket::countByUser prepare failed: " . $conn->error);
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result ? (int)$result->fetch_assoc()['cnt'] : 0;
    }

    public static function count($conn) {
        $sql = "SELECT COUNT(*) AS cnt FROM tickets";
        $result = $conn->query($sql);
        return $result ? (int)$result->fetch_assoc()['cnt'] : 0;
    }

    public static function getRecentByUser($conn, $userId, $limit = 5) {
        $sql = "SELECT t.*, e.title AS event, e.date, e.venue
                FROM tickets t
                JOIN events e ON t.event_id = e.id
                WHERE t.user_id = ?
                ORDER BY t.time DESC
                LIMIT ?";
        $stmt = $conn->prepare($sql);
        if (!$stmt) throw new Exception("Ticket::getRecentByUser prepare failed: " . $conn->error);
        $stmt->bind_param("ii", $userId, $limit);
        $stmt->execute();
        $result = $stmt->get_result();
        $tickets = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];

        foreach ($tickets as &$ticket) {
            $ticket['price_formatted'] = self::formatEGP($ticket['price']);
        }
        return $tickets;
    }

        public static function getTotalSpentByUser($conn, $userId) {
        $sql = "SELECT SUM(price) AS totalSpent FROM tickets WHERE user_id = ?";
        $stmt = $conn->prepare($sql);
        if (!$stmt) throw new Exception("Ticket::getTotalSpentByUser prepare failed: " . $conn->error);
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        return $row['totalSpent'] ?? 0;
    }

    public static function getByUserAndEvent($conn, $userId, $eventId) {
        $sql = "SELECT * FROM tickets WHERE user_id = ? AND event_id = ?";
        $stmt = $conn->prepare($sql);
        if (!$stmt) throw new Exception("Ticket::getByUserAndEvent prepare failed: " . $conn->error);
        $stmt->bind_param("ii", $userId, $eventId);
        $stmt->execute();
        $result = $stmt->get_result();
        $tickets = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];

        foreach ($tickets as &$ticket) {
            $ticket['price_formatted'] = self::formatEGP($ticket['price']);
        }
        return $tickets;
    }

    public static function getByIds($conn, $ticketIds, $userId) {
        if (empty($ticketIds)) return [];

        $placeholders = implode(',', array_fill(0, count($ticketIds), '?'));
        $types = str_repeat('i', count($ticketIds)) . 'i'; // ticket IDs + userId

        $sql = "SELECT * FROM tickets WHERE id IN ($placeholders) AND user_id = ?";
        $stmt = $conn->prepare($sql);
        if (!$stmt) throw new Exception("Ticket::getByIds prepare failed: " . $conn->error);

        $params = array_merge($ticketIds, [$userId]);
        $stmt->bind_param($types, ...$params);

        if (!$stmt->execute()) throw new Exception("Ticket::getByIds execute failed: " . $stmt->error);

        $result = $stmt->get_result();
        $tickets = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];

        foreach ($tickets as &$ticket) {
            $ticket['price_formatted'] = self::formatEGP($ticket['price']);
        }
        return $tickets;
    }

    public static function getTotalRevenue($conn) {
        $sql = "SELECT SUM(price) AS revenue FROM tickets";
        $result = $conn->query($sql);
        if (!$result) throw new Exception("Ticket::getTotalRevenue query failed: " . $conn->error);
        $row = $result->fetch_assoc();
        return (float)($row['revenue'] ?? 0);
    }
}