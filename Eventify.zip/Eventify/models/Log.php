<?php
// ---------------- OBSERVER INTERFACE ----------------
interface Observer {
    public function update($subject, $action, $status = 'success');
}

// ---------------- LOG MODEL ----------------
class Log {
    public static function create($conn, $userId, $action, $status = 'success') {
        // Only allow specific statuses
        $allowed = ['success','warning','error'];
        if (!in_array($status, $allowed)) {
            $status = 'success';
        }

        $sql = "INSERT INTO logs (user_id, action, status, timestamp) VALUES (?, ?, ?, NOW())";
        $stmt = $conn->prepare($sql);
        if (!$stmt) {
            throw new Exception("Log::create prepare failed: " . $conn->error);
        }

        $stmt->bind_param("iss", $userId, $action, $status);
        if (!$stmt->execute()) {
            throw new Exception("Log::create execute failed: " . $stmt->error);
        }
        return true;
    }

    public static function all($conn) {
        $sql = "SELECT logs.*, users.name AS user_name 
                FROM logs 
                LEFT JOIN users ON logs.user_id = users.id 
                ORDER BY id DESC";
        $result = $conn->query($sql);
        return $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
    }
}

// ---------------- LOG OBSERVER ----------------
class LogObserver implements Observer {
    private $conn;

    public function __construct($conn) {
        $this->conn = $conn;
    }

    public function update($subject, $action, $status = 'success') {
        $userId = $subject->user_id ?? null;
        $actor  = $subject->actor ?? ($_SESSION['user_name'] ?? 'System');
        $entity = $subject->entity ?? 'Unknown';
        $label  = $subject->label ?? '';

        // Build a clear message
        $message = "$actor $action $entity: $label";

        try {
            Log::create($this->conn, $userId, $message, $status);
        } catch (Exception $e) {
            error_log("LogObserver update failed: " . $e->getMessage());
        }
    }
}